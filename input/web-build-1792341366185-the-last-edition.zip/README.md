# THE LAST EDITION — Native Android Detective Simulation

> *"VERITAS IN OBSCURIS" — The Greybridge Gazette, Established 1888*

**THE LAST EDITION** is an immersive, standalone, native Android detective simulation game built with **Kotlin** and **Jetpack Compose**. The player takes the role of the night editor of *The Greybridge Gazette*, a struggling newspaper in the rain-slicked industrial city of Greybridge in October 1947.

When a printed front page dated tomorrow describes the murder of foundry foreman Arthur Pendelton hours before the crime occurs, you must investigate the mystery, manage sources, cross-reference evidence, interrogate suspects, and meet the 03:00 AM print deadline.

---

## Key Features

1. **Newspaper-Inspired Visual Design**:
   - Warm ivory paper background, deep charcoal print ink, muted sepia accents, and authentic hairline double-rule dividers.
   - Editorial typography powered by local static Google Fonts: **Playfair Display** (headlines) and **Courier Prime** (typewriter case notes & timestamps).
   - Custom 1940s linocut adaptive launcher icon and Greybridge skyline hero banner.

2. **Mobile-First Newspaper Navigation**:
   - **FRONT PAGE**: Live layout of tonight's edition, banner headline assignment, live deadline clock countdown, and rotary press trigger.
   - **CITY DESK**: Newsroom headquarters, dispatching reporters, map of Greybridge industrial districts (Vulcan Slagworks, St. Jude's, 4th Precinct, Black Dog Tavern).
   - **CASE FILES**: Evidence drawer with category filters, full-text search, user notes, interactive "Compare & Deduce" contradiction board, and night timeline.
   - **SOURCES**: Informant dossiers (Silas Thorne, Nora Vance, Arthur Pendelton, Inspector Reed, Alderman Voss) with multi-stance interviews (Neutral, Evidence Confrontation, Contradiction Challenge, Confidentiality Pledge, Information Trade).
   - **ARCHIVE**: Gazette Morgue of printed editions, chronological night journal, 8-chapter campaign selector, 3-slot save/load manager, and accessibility settings.

3. **Autonomous & Fully Offline**:
   - All game logic, dialogue trees, evidence deductions, and storylines run 100% on-device.
   - No external server or AI API calls required during gameplay.
   - Local, versioned JSON storage persists campaign progress, evidence notes, source trust scores, and printed front pages.

4. **8-Chapter Deep Narrative Campaign**:
   - Chapter 1: *Tomorrow's Murder*
   - Chapter 2: *The Missing Column*
   - Chapter 3: *Paper Witnesses*
   - Chapter 4: *The Quiet District*
   - Chapter 5: *Names in the Ledger*
   - Chapter 6: *The False Edition*
   - Chapter 7: *The City on Record*
   - Chapter 8: *The Last Edition*

5. **Interactive Guided Tutorial**:
   - "The First Night Shift" (10-step actionable tutorial introducing evidence examination, contradiction cross-referencing, interview stances, headline assignment, and press printing). Replayable at any time.

---

## Build and Packaging Instructions

### Prerequisites
- Android SDK 34+ (compileSdk: 36)
- JDK 17 or JDK 21
- Gradle 8+

### Building the Debug APK
To compile and assemble the installable debug APK from the project root:

```bash
gradle assembleDebug
```

### Verified Output Path
Upon completion, the installable Android APK is generated at:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Installing on an Android Device
You can install the debug APK onto any connected Android phone or tablet via ADB:

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

Or copy `app-debug.apk` directly to your phone's storage and open it in the Files app (enabling "Install unknown apps" in Settings).

---

## Architecture Overview

- `com.example.model`: Strongly typed domain entities (`EvidenceItem`, `SourceCharacter`, `NewspaperStory`, `Chapter`, `PrintedEdition`, `GameSaveData`).
- `com.example.data`:
  - `GameContentRepository`: Comprehensive authored narrative content, clue trees, and historical branches.
  - `SaveManager`: Local file-based JSON persistence engine with auto-save and manual slots.
- `com.example.viewmodel`:
  - `GameViewModel`: StateFlow-driven game engine managing the clock, evidence deduction comparisons, interview trees, story slots, and campaign transitions.
- `com.example.ui.theme`:
  - `Color.kt`, `Type.kt`, `Theme.kt`: Authentic 1940s newsprint styling with Playfair Display and Courier Prime.
- `com.example.ui.components`:
  - `NewspaperHeader.kt`: Gazette masthead with date stamp and live deadline countdown.
  - `NewspaperComponents.kt`: Vintage cards, red stamps, credibility meters, buttons.
  - `BottomNavBar.kt`: Compact newspaper index bottom navigation bar.
- `com.example.ui.screens`:
  - `FrontPageScreen`, `CityDeskScreen`, `CaseFilesScreen`, `SourcesScreen`, `ArchiveScreen`, `EvidenceDetailDialog`, `StoryEditorDialog`, `TutorialOverlay`, `ResolutionDialog`.
