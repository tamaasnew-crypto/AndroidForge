package com.example.data

import com.example.model.*

object GameContentRepository {

  val chapters: List<Chapter> = listOf(
    Chapter(
      id = 1,
      title = "Tomorrow's Murder",
      subtitle = "The Future-Dated Gazette & The Night Shift",
      historicalDate = "October 18, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "A freshly printed newspaper dated tomorrow describes the murder of foundry foreman Arthur Pendelton before it happens.",
      narrativeIntro = "Rain lashes the grime-streaked windows of the Greybridge Gazette editorial floor. It is 11:00 PM. Down in the subterranean press room, the giant Goss rotary presses are coughing black ink. Jimmy, the copy boy, dropped a freshly inked front page on your desk. The banner headline reads: 'FOUNDRY FOREMAN SLAIN IN HARBOR ALLEY'. The dateline is tomorrow morning: October 19, 1947. Arthur Pendelton is named as the victim. But Arthur Pendelton is still alive right now.",
      initialEvidenceIds = listOf("ev_c1_future_paper", "ev_c1_police_memo", "ev_c1_payroll"),
      initialLeadIds = listOf("lead_c1_pressroom", "lead_c1_blackdog", "lead_c1_slagworks"),
      initialSourceIds = listOf("src_silas_thorne", "src_nora_vance", "src_arthur_pendelton"),
      initialStoryIds = listOf("story_c1_ghost_edition", "story_c1_pendelton_threat", "story_c1_dock_curfew"),
      keyDeductionId = "ded_c1_prewritten_leak"
    ),
    Chapter(
      id = 2,
      title = "The Missing Column",
      subtitle = "The Ghost of Julian Graves",
      historicalDate = "October 19, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "Investigative reporter Julian Graves vanished three weeks ago. A suppressed carbon copy hidden in his old desk reveals contraband shipments.",
      narrativeIntro = "Following the shocking revelations of the first night shift, you scour the Gazette archives. Desk 4 in the morgue has been locked since Julian Graves walked out into the river fog and never returned. In the hollow belly of his Underwood typewriter, you find carbon sheets that the publisher ordered burned.",
      initialEvidenceIds = listOf("ev_c2_carbon_copy", "ev_c2_dock_manifest", "ev_c2_sister_letter"),
      initialLeadIds = listOf("lead_c2_warehouse7", "lead_c2_graves_flat", "lead_c2_city_hall"),
      initialSourceIds = listOf("src_nora_vance", "src_alderman_voss", "src_martha_graves"),
      initialStoryIds = listOf("story_c2_graves_suppression", "story_c2_contraband_ore", "story_c2_council_denial"),
      keyDeductionId = "ded_c2_smuggled_ore"
    ),
    Chapter(
      id = 3,
      title = "Paper Witnesses",
      subtitle = "The Midnight Transit Logs",
      historicalDate = "October 20, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "Reconstruct the timeline of the fatal night using streetcar schedules, bridge toll receipts, and conflicting officer logs.",
      narrativeIntro = "The police insist Arthur Pendelton was killed by random waterfront toughs at midnight. But paper leaves an indelible trail. You assemble transit slips, municipal toll logs, and harbor signal registers to test the authorities' alibis.",
      initialEvidenceIds = listOf("ev_c3_streetcar_log", "ev_c3_toll_ticket", "ev_c3_patrol_dispatch"),
      initialLeadIds = listOf("lead_c3_car_depot", "lead_c3_iron_bridge", "lead_c3_precinct_morgue"),
      initialSourceIds = listOf("src_inspector_reed", "src_streetcar_motorman", "src_nora_vance"),
      initialStoryIds = listOf("story_c3_fabricated_alibi", "story_c3_bridge_toll_fraud", "story_c3_patrol_mystery"),
      keyDeductionId = "ded_c3_staged_crime_scene"
    ),
    Chapter(
      id = 4,
      title = "The Quiet District",
      subtitle = "Silence Over St. Jude's",
      historicalDate = "October 21, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "In the soot-choked tenements of St. Jude's parish, the Iron Union workers refuse to talk to the press after three mysterious 'accidents'.",
      narrativeIntro = "Between the blast furnaces and the canal lies St. Jude's. The streetlights here have been smashed for a month. Men walk with heads bowed. Three foundry union shop stewards have suffered fatal falls into the quenching vats. The parish priest holds the only truthful registry.",
      initialEvidenceIds = listOf("ev_c4_parish_register", "ev_c4_extortion_note", "ev_c4_coroner_report"),
      initialLeadIds = listOf("lead_c4_st_judes_chapel", "lead_c4_union_hall", "lead_c4_tenement_cellar"),
      initialSourceIds = listOf("src_father_omalley", "src_frank_kowalski", "src_alderman_voss"),
      initialStoryIds = listOf("story_c4_union_intimidation", "story_c4_parish_deaths", "story_c4_foundry_accidents"),
      keyDeductionId = "ded_c4_staged_industrial_accidents"
    ),
    Chapter(
      id = 5,
      title = "Names in the Ledger",
      subtitle = "The Slagworks Audit",
      historicalDate = "October 22, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "Follow the money from the Greybridge Foundry through offshore shell accounts straight into the municipal campaign chests.",
      narrativeIntro = "A courier envelope arrives at the Gazette reception, wrapped in oilcloth. Inside is a leather-bound disbursement ledger from Vulcan Slagworks. The columns list payroll codes that correspond to no working men, but match the badge numbers of the 4th Precinct.",
      initialEvidenceIds = listOf("ev_c5_slush_ledger", "ev_c5_bank_wire_slip", "ev_c5_council_minutes"),
      initialLeadIds = listOf("lead_c5_merchants_bank", "lead_c5_aldermans_club", "lead_c5_dock_offices"),
      initialSourceIds = listOf("src_alderman_voss", "src_bank_auditor", "src_inspector_reed"),
      initialStoryIds = listOf("story_c5_police_payoffs", "story_c5_slush_fund_exposed", "story_c5_alderman_bribe"),
      keyDeductionId = "ded_c5_precinct_bribery"
    ),
    Chapter(
      id = 6,
      title = "The False Edition",
      subtitle = "Sabotage on the Linotype",
      historicalDate = "October 23, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "Identify the insider at The Greybridge Gazette who smuggled the forged type matrix into our own printing press.",
      narrativeIntro = "The call came from the District Attorney: the Gazette faces immediate charges of inciting panic. Whoever authorized the future-dated press run had keys to the editor's safe and knowledge of the telegraph cipher.",
      initialEvidenceIds = listOf("ev_c6_linotype_matrix", "ev_c6_editors_memo", "ev_c6_janitor_log"),
      initialLeadIds = listOf("lead_c6_typeset_lockers", "lead_c6_exec_office", "lead_c6_telegraph_room"),
      initialSourceIds = listOf("src_silas_thorne", "src_publisher_henderson", "src_nora_vance"),
      initialStoryIds = listOf("story_c6_internal_sabotage", "story_c6_press_blackmail", "story_c6_da_threat"),
      keyDeductionId = "ded_c6_publisher_extortion"
    ),
    Chapter(
      id = 7,
      title = "The City on Record",
      subtitle = "The Unbroken Syndicate",
      historicalDate = "October 24, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "Confront Police Commissioner Harlan Cross and District Attorney Sterling with the accumulated paper trail.",
      narrativeIntro = "The net is tightening. The 4th Precinct has positioned patrol wagons outside the Gazette building on Iron Street. Inside, your reporters have turned the newsroom into a fortified bunker of filing cabinets and telephone switchboards.",
      initialEvidenceIds = listOf("ev_c7_commissioner_order", "ev_c7_grand_jury_deposition", "ev_c7_wiretap_log"),
      initialLeadIds = listOf("lead_c7_police_hq", "lead_c7_da_chambers", "lead_c7_mayors_residence"),
      initialSourceIds = listOf("src_commissioner_cross", "src_nora_vance", "src_inspector_reed"),
      initialStoryIds = listOf("story_c7_cross_conspiracy", "story_c7_city_hall_ultimatum", "story_c7_grand_jury_leak"),
      keyDeductionId = "ded_c7_syndicate_command"
    ),
    Chapter(
      id = 8,
      title = "The Last Edition",
      subtitle = "The Final Print Run",
      historicalDate = "October 25, 1947",
      deadlineClockTime = "03:00 AM",
      totalNightMinutes = 240,
      briefSummary = "The presses are warmed for the final morning edition. Choose how to break the story to the city before the police raid.",
      narrativeIntro = "Steam hisses from the boilers beneath the floorboards. It is 2:30 AM. Downstairs, five hundred reams of newsprint sit threaded through the cylinders. Outside, sirens wail across the iron bridge. In fifteen minutes, the ink roller will touch the lead plates. Whatever you set tonight will become the permanent history of Greybridge.",
      initialEvidenceIds = listOf("ev_c8_final_manifesto", "ev_c8_cross_confession", "ev_c8_syndicate_charter"),
      initialLeadIds = listOf("lead_c8_press_controls", "lead_c8_delivery_vans", "lead_c8_telegraph_syndication"),
      initialSourceIds = listOf("src_nora_vance", "src_publisher_henderson", "src_commissioner_cross"),
      initialStoryIds = listOf("story_c8_unvarnished_expose", "story_c8_cautious_indictment", "story_c8_compromise_edition"),
      keyDeductionId = "ded_c8_the_complete_truth"
    )
  )

  val allEvidence: List<EvidenceItem> = listOf(
    // Chapter 1
    EvidenceItem(
      id = "ev_c1_future_paper",
      chapterId = 1,
      title = "The Tomorrow Gazette (Oct 19 Issue)",
      category = EvidenceCategory.NEWSPAPER_CLIPPING,
      source = "Press Room Rotary Floor",
      dateObtained = "Oct 18, 11:05 PM",
      shortDescription = "Printed newspaper dated tomorrow detailing the murder of Arthur Pendelton at Wharf Alley 4.",
      detailedContent = "Headline: 'FOUNDRY FOREMAN SLAIN IN HARBOR ALLEY'. Dateline: Greybridge, Oct 19, 1947.\n\nText quotes Coroner Dr. Emil Vance: 'Blunt force trauma to the occipital bone, consistent with an iron wrench.' Mentions police dispatch 44-B at 00:15 AM. Crucially, the slug lines bear Linotype machine #3's distinct notched serif signature. Someone set this type before the event occurred.",
      peopleInvolved = listOf("Arthur Pendelton", "Dr. Emil Vance", "Silas Thorne"),
      locationsInvolved = listOf("Wharf Alley 4", "Gazette Press Room"),
      connections = listOf("ev_c1_police_memo", "ev_c1_payroll"),
      status = EvidenceStatus.UNCONFIRMED,
      isKeyClue = true
    ),
    EvidenceItem(
      id = "ev_c1_police_memo",
      chapterId = 1,
      title = "Confidential Police Memo #44-B",
      category = EvidenceCategory.OFFICIAL_DOCUMENT,
      source = "Nora Vance's City Hall Leak",
      dateObtained = "Oct 18, 11:20 PM",
      shortDescription = "Classified 4th Precinct directive ordering patrols away from Wharf Alley between 11:30 PM and 1:00 AM.",
      detailedContent = "CONFIDENTIAL DIRECTIVE — 4th PRECINCT\nTo: Desk Sergeant Miller\nSubject: Special Operation 'Lantern'\n\n'All beat officers will maintain strict perimeter along River St. Under no circumstances will patrols enter Wharf Alleys 1 through 6 between 23:30 and 01:00 hours. Any civilian reports of disturbances in this zone will be held until morning shift review.' Signed: Inspector Thomas Reed.",
      peopleInvolved = listOf("Inspector Thomas Reed", "Desk Sergeant Miller"),
      locationsInvolved = listOf("4th Precinct", "Wharf Alley 4"),
      connections = listOf("ev_c1_future_paper"),
      status = EvidenceStatus.UNCONFIRMED,
      isKeyClue = true
    ),
    EvidenceItem(
      id = "ev_c1_payroll",
      chapterId = 1,
      title = "Vulcan Slagworks Night Shift Log",
      category = EvidenceCategory.FINANCIAL_RECORD,
      source = "Slagworks Gatekeeper Booth",
      dateObtained = "Oct 18, 11:45 PM",
      shortDescription = "Arthur Pendelton's timecard showing he clocked in at 10:45 PM tonight and left abruptly at 11:10 PM.",
      detailedContent = "TIME CARD #882 — ARTHUR PENDELTON, FOREMAN.\nShift: Oct 18, 23:00 to 07:00.\nIn: 22:45.\nOut: 23:10 (EMERGENCY DEPARTURE NOTED BY GATE GUARD).\nGuard's scribbled pencil note on reverse: 'Arthur received phone call at booth from a man calling himself \"The Typist\". Looked ashen white, ran out toward Black Dog Tavern.'",
      peopleInvolved = listOf("Arthur Pendelton", "The Typist"),
      locationsInvolved = listOf("Vulcan Slagworks Gate 3", "Black Dog Tavern"),
      connections = listOf("ev_c1_future_paper"),
      status = EvidenceStatus.VERIFIED
    ),
    EvidenceItem(
      id = "ev_c1_taxi_receipt",
      chapterId = 1,
      title = "Yellow Cab Dispatch Slip #104",
      category = EvidenceCategory.PHYSICAL,
      source = "Wastebasket outside Linotype #3",
      dateObtained = "Oct 19, 00:15 AM",
      shortDescription = "Receipt for a cab trip from City Hall to the Gazette offices at 10:15 PM.",
      detailedContent = "GREYBRIDGE TAXI SERVICE — METER #104\nPickup: City Hall Executive Annex, 10:15 PM.\nDropoff: Greybridge Gazette Alley Entrance, 10:35 PM.\nFare: $1.40. Paid in brand new bills. Driver note: 'Passenger carried heavy wooden lockbox wrapped in oilskin.'",
      peopleInvolved = listOf("Silas Thorne", "Alderman Donald Voss"),
      locationsInvolved = listOf("City Hall Annex", "Gazette Alley"),
      status = EvidenceStatus.UNCONFIRMED
    ),

    // Chapter 2
    EvidenceItem(
      id = "ev_c2_carbon_copy",
      chapterId = 2,
      title = "Julian Graves' Suppressed Draft",
      category = EvidenceCategory.CORRESPONDENCE,
      source = "Underside of Typewriter #4",
      dateObtained = "Oct 19, 08:30 AM",
      shortDescription = "Investigation notes detailing illegal titanium ore shipments funneled through Warehouse 7.",
      detailedContent = "'If Henderson spikes this column, whoever finds these carbons must know: the iron shipments from the North Range are 40% undeclared high-grade titanium ore. The profits bypass customs and are laundered through Alderman Voss's construction dummy firms. Pendelton knew the weights didn't match the manifests.'",
      peopleInvolved = listOf("Julian Graves", "Alderman Donald Voss", "Publisher Henderson"),
      locationsInvolved = listOf("Warehouse 7", "North Range Docks"),
      status = EvidenceStatus.UNCONFIRMED,
      isKeyClue = true
    ),
    EvidenceItem(
      id = "ev_c2_dock_manifest",
      chapterId = 2,
      title = "Harbor Manifest #409 (Steamer 'Cynthia')",
      category = EvidenceCategory.OFFICIAL_DOCUMENT,
      source = "Customs House Basement",
      dateObtained = "Oct 19, 10:00 AM",
      shortDescription = "Cargo log showing 500 tons of 'scrap iron' consigned to an unlisted holding company.",
      detailedContent = "CARGO REGISTRY: S.S. Cynthia, Berth 3.\nDeclared: 500 Tons Raw Scrap Iron.\nConsignee: Greybridge Allied Transit (P.O. Box 92).\nSign-off stamp missing municipal inspection seal. Marked 'EXEMPT BY SPECIAL COMMISSIONER ORDER'.",
      peopleInvolved = listOf("Police Commissioner Harlan Cross"),
      locationsInvolved = listOf("Berth 3", "Customs House"),
      status = EvidenceStatus.VERIFIED
    ),
    EvidenceItem(
      id = "ev_c2_sister_letter",
      chapterId = 2,
      title = "Letter from Martha Graves",
      category = EvidenceCategory.CORRESPONDENCE,
      source = "Delivered to Gazette Mailroom",
      dateObtained = "Oct 19, 11:15 AM",
      shortDescription = "Julian's sister warns that Julian was followed by two men in dark trench coats driving a black Buick.",
      detailedContent = "'Dear Editor: Julian visited my house on Thursday before he vanished. He gave me a safe-deposit key and told me that if anything happened to him, check the Gazette's own printing ink suppliers. The ink drums aren't carrying ink.'",
      peopleInvolved = listOf("Martha Graves", "Julian Graves"),
      locationsInvolved = listOf("Graves Residence", "Gazette Mailroom"),
      status = EvidenceStatus.UNCONFIRMED
    ),

    // Chapter 3
    EvidenceItem(
      id = "ev_c3_streetcar_log",
      chapterId = 3,
      title = "Streetcar Route 14 Dispatch Sheet",
      category = EvidenceCategory.TIMELINE,
      source = "Greybridge Traction Co. Depot",
      dateObtained = "Oct 20, 01:20 AM",
      shortDescription = "Conductor's log detailing streetcar delay at Iron Bridge due to police blockade at 11:45 PM.",
      detailedContent = "CAR #42 — CONDUCTOR O'BRIEN:\n'Halted at north ramp of Iron Bridge at 23:45 by two patrolmen. Ordered to douse cabin lamps and wait 20 minutes while an unmarked covered truck crossed toward the Slagworks. No passenger allowed out.'",
      peopleInvolved = listOf("Conductor O'Brien", "Inspector Thomas Reed"),
      locationsInvolved = listOf("Iron Bridge", "Traction Depot"),
      status = EvidenceStatus.VERIFIED,
      isKeyClue = true
    ),
    EvidenceItem(
      id = "ev_c3_toll_ticket",
      chapterId = 3,
      title = "Municipal Bridge Toll Register",
      category = EvidenceCategory.FINANCIAL_RECORD,
      source = "Bridge Tollbooth Archive",
      dateObtained = "Oct 20, 02:00 AM",
      shortDescription = "Entry recording black Buick plate #GB-9902 exempt from toll under City Council pass.",
      detailedContent = "TOLL REGISTER — IRON BRIDGE.\nTime: 23:55.\nVehicle: Black Buick Sedan, Plate GB-9902.\nPassholder: Alderman Donald Voss.\nDirection: Southbound toward Wharf 7.",
      peopleInvolved = listOf("Alderman Donald Voss"),
      locationsInvolved = listOf("Iron Bridge Tollgate"),
      status = EvidenceStatus.VERIFIED
    ),
    EvidenceItem(
      id = "ev_c3_patrol_dispatch",
      chapterId = 3,
      title = "4th Precinct Official Radio Log",
      category = EvidenceCategory.CONTRADICTORY_STATEMENT,
      source = "Station Radio Desk",
      dateObtained = "Oct 20, 02:30 AM",
      shortDescription = "Officer Reed logged his cruiser at 5th and Main at 11:50 PM, directly contradicting the toll record.",
      detailedContent = "RADIO CALL 11:50 PM: 'Car 4 (Inspector Reed) reporting 10-4 at 5th and Main. Routine patrol.'\nContradiction: 5th and Main is 4.5 miles from Iron Bridge. Reed could not physically have crossed Iron Bridge at 23:55 while being at 5th and Main at 23:50.",
      peopleInvolved = listOf("Inspector Thomas Reed"),
      locationsInvolved = listOf("5th & Main", "Iron Bridge"),
      status = EvidenceStatus.DISPUTED
    ),

    // Chapter 4
    EvidenceItem(
      id = "ev_c4_parish_register",
      chapterId = 4,
      title = "St. Jude's Sick & Deceased Ledger",
      category = EvidenceCategory.OFFICIAL_DOCUMENT,
      source = "Father O'Malley's Rectory Safe",
      dateObtained = "Oct 21, 01:10 AM",
      shortDescription = "Priest's private notes recording wounds on deceased foundry workers incompatible with accidental burns.",
      detailedContent = "ENTRY FOR T. WALSH (SHOP STEWARD):\n'Official cause: Ladle spillage burn. Private pastoral inspection: victim bore heavy ligature marks around neck prior to contact with furnace slag. Father O'Malley gave last rites. Family threatened by Voss associates.'",
      peopleInvolved = listOf("Father O'Malley", "Alderman Donald Voss", "T. Walsh"),
      locationsInvolved = listOf("St. Jude's Parish", "Vulcan Slagworks"),
      status = EvidenceStatus.VERIFIED,
      isKeyClue = true
    ),
    EvidenceItem(
      id = "ev_c4_extortion_note",
      chapterId = 4,
      title = "Threat Letter to Union Steward Kowalski",
      category = EvidenceCategory.CORRESPONDENCE,
      source = "Frank Kowalski's Locker",
      dateObtained = "Oct 21, 01:45 AM",
      shortDescription = "Cut-out newspaper letters warning the union to cancel the strike vote before October 25th.",
      detailedContent = "'Kowalski: Your girl walks home past the coal chutes at 5 PM. If the strike ballot is printed in the morning, she won't make it to church on Sunday. Keep the furnace fires burning.'",
      peopleInvolved = listOf("Frank Kowalski"),
      locationsInvolved = listOf("Union Hall #12", "Coal Chutes"),
      status = EvidenceStatus.UNCONFIRMED
    ),

    // Chapter 5
    EvidenceItem(
      id = "ev_c5_slush_ledger",
      chapterId = 5,
      title = "Greybridge Smelting Special Expense Ledger",
      category = EvidenceCategory.FINANCIAL_RECORD,
      source = "Auditor's Safety Box",
      dateObtained = "Oct 22, 00:30 AM",
      shortDescription = "Secret accounts detailing monthly $2,000 cash payments to 'Shield & Gavel'.",
      detailedContent = "ACCOUNT #901 — DISCRETIONARY OVERHEAD:\nJuly: $2,000 — Ref: 'Shield' (Badge 401 - Harlan Cross)\nAugust: $2,000 — Ref: 'Shield'\nSeptember: $2,500 — Ref: 'Gavel' (City Attorney Office)\nOctober: $5,000 — Ref: 'Press Suppression Protocol'.",
      peopleInvolved = listOf("Commissioner Harlan Cross", "Publisher Henderson"),
      locationsInvolved = listOf("Merchants National Bank"),
      status = EvidenceStatus.VERIFIED,
      isKeyClue = true
    ),
    EvidenceItem(
      id = "ev_c5_bank_wire_slip",
      chapterId = 5,
      title = "Swiss Telegraphic Transfer Receipt",
      category = EvidenceCategory.FINANCIAL_RECORD,
      source = "Commercial Bank Vault",
      dateObtained = "Oct 22, 01:15 AM",
      shortDescription = "Transfer of $85,000 to Credit Lyonnais Geneva under account 'AURORA-GREYBRIDGE'.",
      detailedContent = "WIRE TRANSFER NOTICE: $85,000.00 USD.\nBeneficiary: Account 4481-B Geneva.\nAuthorized signature matches Alderman Donald Voss's personal bank seal.",
      peopleInvolved = listOf("Alderman Donald Voss"),
      locationsInvolved = listOf("Geneva, Switzerland", "City Hall"),
      status = EvidenceStatus.VERIFIED
    ),

    // Chapter 6
    EvidenceItem(
      id = "ev_c6_linotype_matrix",
      chapterId = 6,
      title = "Brass Linotype Slug Matrix #3",
      category = EvidenceCategory.PHYSICAL,
      source = "Found hidden in Silas Thorne's Tool Chest",
      dateObtained = "Oct 23, 00:45 AM",
      shortDescription = "The physical brass letters cast to print the tomorrow murder headline, coated in fresh printer's ink.",
      detailedContent = "HEAVY BRASS CAST SLUG:\n'FOUNDRY FOREMAN SLAIN IN HARBOR ALLEY'\nReverse side stamped with proprietary alloy stamp of Greybridge Gazette machine 3. Proof that the type was cast on our premises using our molten lead supply, but fed with pre-punched ticker tape.",
      peopleInvolved = listOf("Silas Thorne", "Publisher Henderson"),
      locationsInvolved = listOf("Gazette Press Room"),
      status = EvidenceStatus.VERIFIED,
      isKeyClue = true
    ),
    EvidenceItem(
      id = "ev_c6_editors_memo",
      chapterId = 6,
      title = "Publisher Henderson's Encrypted Teletype",
      category = EvidenceCategory.OFFICIAL_DOCUMENT,
      source = "Managing Editor's Wastepaper Basket",
      dateObtained = "Oct 23, 01:20 AM",
      shortDescription = "Drafted telegram to Alderman Voss promising to 'spike any story connecting the foundry fire to the council'.",
      detailedContent = "'Donald: The night editor is digging too close to the ore manifests. I have authorized Thorne to run the distraction piece to tie up their headlines. Keep the police commissioner in line.'",
      peopleInvolved = listOf("Publisher Henderson", "Alderman Donald Voss"),
      locationsInvolved = listOf("Executive Suite, 4th Floor"),
      status = EvidenceStatus.VERIFIED
    ),

    // Chapter 7
    EvidenceItem(
      id = "ev_c7_commissioner_order",
      chapterId = 7,
      title = "Commissioner Cross's Martial Standby Order",
      category = EvidenceCategory.OFFICIAL_DOCUMENT,
      source = "Police Headquarters Confidential Vault",
      dateObtained = "Oct 24, 01:00 AM",
      shortDescription = "Signed warrant authorizing the immediate seizure of The Greybridge Gazette printing presses at 03:00 AM.",
      detailedContent = "SPECIAL DECREE — CITY EMERGENCY POWERS:\n'In the interest of public order, the Chief of Police is empowered to impound all printing presses, plates, and distribution trucks of The Greybridge Gazette effective 03:00 AM Oct 25, citing violation of the Sedition & Libel Act of 1918.' Signed: Harlan Cross, Commissioner.",
      peopleInvolved = listOf("Commissioner Harlan Cross"),
      locationsInvolved = listOf("Police Headquarters"),
      status = EvidenceStatus.VERIFIED,
      isKeyClue = true
    ),

    // Chapter 8
    EvidenceItem(
      id = "ev_c8_final_manifesto",
      chapterId = 8,
      title = "The Syndicate Master Ledger & Charter",
      category = EvidenceCategory.FINANCIAL_RECORD,
      source = "Assembled from complete campaign clues",
      dateObtained = "Oct 25, 02:15 AM",
      shortDescription = "The undeniable synthesis of corporate theft, police collusion, and murdered reporters controlling Greybridge.",
      detailedContent = "GREYBRIDGE JOINT SYNDICATE CHARTER (1942-1947):\nSignatures: Harlan Cross (Police), Donald Voss (Council), Charles Henderson (Gazette), Marcus Vance (Foundry Smelting).\nEvery ton of ore, every election, every spiked news article was planned in unison.",
      peopleInvolved = listOf("Commissioner Harlan Cross", "Alderman Donald Voss", "Publisher Henderson"),
      locationsInvolved = listOf("Greybridge City Hall"),
      status = EvidenceStatus.VERIFIED,
      isKeyClue = true
    )
  )

  val allSources: List<SourceCharacter> = listOf(
    SourceCharacter(
      id = "src_silas_thorne",
      name = "Silas Thorne",
      role = "Senior Linotype Operator",
      affiliation = "The Greybridge Gazette (Press Room)",
      location = "Basement Foundry & Press Pit",
      background = "A 28-year veteran typesetter whose fingers are stained indelible Prussian blue with printer's lead and oil. Bitter, underpaid, and deeply indebted to dock loan sharks.",
      knownInformation = "Knows who slipped him the handwritten copy for tomorrow's front page and the exact machine used to cast the metal slug.",
      conflictOfInterest = "Took a $300 payoff from a City Hall courier to sneak the plate onto Rotary Press #2 during the 10:30 PM tea break.",
      trustScore = 15,
      dialogueTree = mapOf(
        "root" to SourceDialogueNode(
          nodeKey = "root",
          prompt = "Silas wipes greasy ink from his spectacles with an oily rag. He won't meet your gaze. 'Night editor... shouldn't you be upstairs writing theater reviews? We got a deadline in three hours.'",
          options = listOf(
            DialogueOption(
              id = "opt_silas_neutral",
              text = "What was running on Press #2 during the 10:30 tea break?",
              stance = DialogueStance.NEUTRAL_QUESTION,
              responseText = "Silas snorts nervously. 'Just test proofs, boss. Rollers needed greasing. We always run a dummy sheet to balance the ink fountains. Nothing unusual.'",
              trustDelta = 2,
              timeCostMinutes = 20,
              nextDialogueKey = "inquire_more"
            ),
            DialogueOption(
              id = "opt_silas_evidence",
              text = "Show him the tomorrow-dated newspaper with his machine's slug notch.",
              stance = DialogueStance.PRESENT_EVIDENCE,
              requiredEvidenceId = "ev_c1_future_paper",
              responseText = "Silas goes rigid. His hand shakes as he takes the damp newsprint. 'God Almighty... where did you pick this up? It wasn't supposed to hit the bundle chute until tomorrow dawn!'",
              trustDelta = 10,
              revealsEvidenceId = "ev_c1_taxi_receipt",
              timeCostMinutes = 30,
              nextDialogueKey = "confronted"
            ),
            DialogueOption(
              id = "opt_silas_press",
              text = "Challenge him: 'Arthur Pendelton is still alive right now. You cast an obituary for a living man!'",
              stance = DialogueStance.CHALLENGE_CONTRADICTION,
              requiredEvidenceId = "ev_c1_payroll",
              responseText = "Silas breaks. 'I had no choice! A fellow met me at the alley door with a handwritten copy and a wad of fifties. Said if I didn't cast it, my boy Tommy at the ironworks would have an \"accident\" in the furnace pit!'",
              trustDelta = 25,
              revealsLeadId = "lead_c1_blackdog",
              timeCostMinutes = 25,
              nextDialogueKey = "confessed"
            ),
            DialogueOption(
              id = "opt_silas_protect",
              text = "Pledge confidentiality: 'Give me the courier's description and your name stays strictly off the record.'",
              stance = DialogueStance.PROTECT_IDENTITY,
              responseText = "Silas exhales a shuddering breath. 'He was driving a black municipal Buick. Had a golden lapel pin shaped like an anvil. Said Arthur was hiding out at the Black Dog Tavern behind the malt house.'",
              trustDelta = 20,
              timeCostMinutes = 20,
              nextDialogueKey = "confessed"
            ),
            DialogueOption(
              id = "opt_silas_end",
              text = "Leave the press room for now.",
              stance = DialogueStance.END_INTERVIEW,
              responseText = "Silas nods jerkily. 'Don't let Henderson catch you poking around the matrix bins.'",
              timeCostMinutes = 5,
              nextDialogueKey = "root"
            )
          )
        ),
        "inquire_more" to SourceDialogueNode(
          nodeKey = "inquire_more",
          prompt = "Silas keeps his wrench gripped tight. 'Look, I just melt the lead and hit the keys. Ask Henderson if you want editorial policy.'",
          options = listOf(
            DialogueOption(
              id = "opt_silas_bargain",
              text = "Trade information: 'We found the police dispatch memo. The cops aren't going to protect whoever did this.'",
              stance = DialogueStance.BARGAIN_INFO,
              requiredEvidenceId = "ev_c1_police_memo",
              responseText = "Silas drops his wrench with a loud clatter. 'The cops are IN on it? Jesus... Arthur called me from the gate booth an hour ago. He knows he's marked.'",
              trustDelta = 15,
              revealsLeadId = "lead_c1_blackdog",
              timeCostMinutes = 20,
              nextDialogueKey = "confessed"
            ),
            DialogueOption(
              id = "opt_silas_back",
              text = "Step back to the main questions.",
              stance = DialogueStance.NEUTRAL_QUESTION,
              responseText = "'Yeah, go on.'",
              timeCostMinutes = 5,
              nextDialogueKey = "root"
            )
          )
        ),
        "confronted" to SourceDialogueNode(
          nodeKey = "confronted",
          prompt = "Silas looks like a man standing before a firing squad. 'If they know I talked to you, they'll throw me into the canal.'",
          options = listOf(
            DialogueOption(
              id = "opt_silas_confessed_1",
              text = "Where is Arthur Pendelton right now?",
              stance = DialogueStance.NEUTRAL_QUESTION,
              responseText = "'Back room of the Black Dog Tavern. He's got a locked valise with the real shipping manifests. He was waiting for midnight to catch the train to Chicago.'",
              trustDelta = 10,
              revealsLeadId = "lead_c1_blackdog",
              timeCostMinutes = 15
            ),
            DialogueOption(
              id = "opt_silas_confessed_2",
              text = "Who gave you the handwritten text?",
              stance = DialogueStance.CHALLENGE_CONTRADICTION,
              responseText = "'Alderman Voss's private driver. Dropped it off in a manila envelope sealed with red wax.'",
              trustDelta = 10,
              revealsLeadId = "lead_c1_slagworks",
              timeCostMinutes = 15
            )
          )
        ),
        "confessed" to SourceDialogueNode(
          nodeKey = "confessed",
          prompt = "Silas sits on a stack of newsprint paper rolls. 'You've got what you need. Get to Arthur before the 4th Precinct does.'",
          options = listOf(
            DialogueOption(
              id = "opt_silas_done",
              text = "Wrap up the interview.",
              stance = DialogueStance.END_INTERVIEW,
              responseText = "'God help this newspaper,' Silas whispers.",
              timeCostMinutes = 5,
              nextDialogueKey = "root"
            )
          )
        )
      )
    ),

    SourceCharacter(
      id = "src_nora_vance",
      name = "Nora Vance",
      role = "City Hall & Police Beat Reporter",
      affiliation = "The Greybridge Gazette",
      location = "Gazette City Desk (Typewriter 2)",
      background = "Razor-sharp, chain-smoking Lucky Strikes, Nora knows every cop, clerk, and alderman in Greybridge. Her father was an honest union coroner before he was forced out.",
      knownInformation = "Has an active confidential pipeline inside the 4th Precinct dispatch office and intercepted the 'Operation Lantern' memo.",
      conflictOfInterest = "Wants to bring down Police Commissioner Harlan Cross for personal reasons involving her family's ruin.",
      trustScore = 45,
      dialogueTree = mapOf(
        "root" to SourceDialogueNode(
          nodeKey = "root",
          prompt = "Nora pulls off her trench coat and lights a fresh cigarette with a bronze Zippo. 'Night editor. Word from the 4th is they just blacked out radio channels for the river district. Something dirty is going down tonight.'",
          options = listOf(
            DialogueOption(
              id = "opt_nora_memo",
              text = "Ask about Confidential Police Memo #44-B and 'Operation Lantern'.",
              stance = DialogueStance.NEUTRAL_QUESTION,
              requiredEvidenceId = "ev_c1_police_memo",
              responseText = "Nora leans in close. 'That came straight off Inspector Reed's desk. The cops are clearing the docks so someone can do a clean job without witnesses. And look at the timing: 11:30 PM tonight.'",
              trustDelta = 8,
              timeCostMinutes = 20,
              nextDialogueKey = "nora_details"
            ),
            DialogueOption(
              id = "opt_nora_future",
              text = "Show her the tomorrow morning edition announcing Arthur Pendelton's murder.",
              stance = DialogueStance.PRESENT_EVIDENCE,
              requiredEvidenceId = "ev_c1_future_paper",
              responseText = "Nora stares at the headline, her cigarette freezing midway to her lips. 'Jesus Mary and Joseph... Silas set this? That means the syndicate is so confident of Arthur's death they're already running the morning paper! We're printing their pre-packaged narrative!'",
              trustDelta = 15,
              revealsLeadId = "lead_c1_slagworks",
              timeCostMinutes = 25,
              nextDialogueKey = "nora_details"
            ),
            DialogueOption(
              id = "opt_nora_end",
              text = "Tell Nora to keep her ear to the precinct telephone.",
              stance = DialogueStance.END_INTERVIEW,
              responseText = "Nora winks tightly. 'I'll have my ear glued to the police wire. Don't print any fairy tales tonight.'",
              timeCostMinutes = 5,
              nextDialogueKey = "root"
            )
          )
        ),
        "nora_details" to SourceDialogueNode(
          nodeKey = "nora_details",
          prompt = "Nora taps the ash into a brass saucer. 'Arthur Pendelton was Julian Graves's secret contact. Julian told me that before he vanished. If Arthur dies, the trail to the ore smuggling goes cold forever.'",
          options = listOf(
            DialogueOption(
              id = "opt_nora_advice",
              text = "What's our editorial play if we reach Arthur alive?",
              stance = DialogueStance.NEUTRAL_QUESTION,
              responseText = "'We run the truth on the front page: Arthur is alive, and the police planned his death. It'll blow the lid off the 4th Precinct. But Henderson will try to kill the story.'",
              trustDelta = 5,
              timeCostMinutes = 15
            ),
            DialogueOption(
              id = "opt_nora_back",
              text = "Return to city desk duties.",
              stance = DialogueStance.END_INTERVIEW,
              responseText = "'Stay sharp, editor.'",
              timeCostMinutes = 5,
              nextDialogueKey = "root"
            )
          )
        )
      )
    ),

    SourceCharacter(
      id = "src_arthur_pendelton",
      name = "Arthur Pendelton",
      role = "Foundry Night Shift Foreman",
      affiliation = "Vulcan Slagworks",
      location = "Back Booth, The Black Dog Tavern",
      background = "A sturdy, grey-templed craftsman with burn scars across his forearms. He worked 22 years at Vulcan Slagworks before uncovering systematic falsification of titanium ore weights.",
      knownInformation = "Possesses the true duplicate shipping manifests and knows the identity of the corrupt inspector who ordered his execution.",
      conflictOfInterest = "Terrified for his wife and children in the North End; desperate to escape Greybridge on the 1:30 AM freight train.",
      trustScore = 10,
      dialogueTree = mapOf(
        "root" to SourceDialogueNode(
          nodeKey = "root",
          prompt = "Inside the dingy, smoke-filled Black Dog Tavern, a man in a greased leather jacket hunches over an untouched draft of beer. His eyes dart toward the door at every creak of the floorboards.",
          options = listOf(
            DialogueOption(
              id = "opt_arthur_identity",
              text = "Introduce yourself as the night editor of The Greybridge Gazette.",
              stance = DialogueStance.NEUTRAL_QUESTION,
              responseText = "Pendelton recoils, his hand diving inside his coat. 'The Gazette? Your paper is owned by Henderson! He drinks at the Greybridge Club with Voss! Get away from me!'",
              trustDelta = -5,
              timeCostMinutes = 15,
              nextDialogueKey = "arthur_scared"
            ),
            DialogueOption(
              id = "opt_arthur_show_paper",
              text = "Slap tomorrow's newspaper on the table: 'Look at the headline, Arthur. You are already dead in tomorrow's edition.'",
              stance = DialogueStance.PRESENT_EVIDENCE,
              requiredEvidenceId = "ev_c1_future_paper",
              responseText = "Pendelton looks at his own name in bold black typeface. The color drains from his face entirely. 'They... they set the type before they even caught me. They think this city is their private slaughterhouse.'",
              trustDelta = 30,
              timeCostMinutes = 20,
              nextDialogueKey = "arthur_open"
            ),
            DialogueOption(
              id = "opt_arthur_protect",
              text = "Pledge: 'I will hold the front page and put a reporter with your family right now. Give us the truth.'",
              stance = DialogueStance.PROTECT_IDENTITY,
              responseText = "Pendelton's shoulders slump. 'You really mean that? You won't let Henderson bury it like he buried Julian Graves's column?'",
              trustDelta = 20,
              timeCostMinutes = 20,
              nextDialogueKey = "arthur_open"
            )
          )
        ),
        "arthur_scared" to SourceDialogueNode(
          nodeKey = "arthur_scared",
          prompt = "Pendelton is ready to bolt out the tavern fire escape.",
          options = listOf(
            DialogueOption(
              id = "opt_arthur_calm",
              text = "Show him the police memo: 'The police aren't coming to protect you. We are your only shield.'",
              stance = DialogueStance.BARGAIN_INFO,
              requiredEvidenceId = "ev_c1_police_memo",
              responseText = "Arthur reads the curfew order. He closes his eyes and trembles. 'Inspector Reed... that bastard sat in my kitchen two weeks ago and drank my cider.'",
              trustDelta = 25,
              timeCostMinutes = 15,
              nextDialogueKey = "arthur_open"
            )
          )
        ),
        "arthur_open" to SourceDialogueNode(
          nodeKey = "arthur_open",
          prompt = "Pendelton opens a battered leather valise under the bench. Inside are carbon copies of chemical analysis slips.",
          options = listOf(
            DialogueOption(
              id = "opt_arthur_manifests",
              text = "What was being smuggled through Warehouse 7?",
              stance = DialogueStance.NEUTRAL_QUESTION,
              responseText = "'High-grade strategic titanium ore from the military stockpile. Voss has been billing the city for scrap iron, melting it down, and selling the pure titanium to unlisted overseas buyers. Julian Graves found the assay reports.'",
              trustDelta = 10,
              revealsEvidenceId = "ev_c2_carbon_copy",
              timeCostMinutes = 25
            ),
            DialogueOption(
              id = "opt_arthur_who_ordered",
              text = "Who gave the order to kill you tonight?",
              stance = DialogueStance.CHALLENGE_CONTRADICTION,
              responseText = "'Inspector Reed came to the gate at 10:30 PM. Told me to walk down Wharf Alley 4 to sign for an urgent delivery. When I saw the streetlights were out, I knew it was an ambush and ran.'",
              trustDelta = 15,
              timeCostMinutes = 20
            ),
            DialogueOption(
              id = "opt_arthur_conclude",
              text = "Advise Arthur to hide in the rectory at St. Jude's while we print the story.",
              stance = DialogueStance.END_INTERVIEW,
              responseText = "'I'm going to Father O'Malley's. Print the truth, editor. Don't let them kill me twice.'",
              timeCostMinutes = 10
            )
          )
        )
      )
    ),

    SourceCharacter(
      id = "src_inspector_reed",
      name = "Inspector Thomas Reed",
      role = "Chief of Detectives, 4th Precinct",
      affiliation = "Greybridge Police Department",
      location = "4th Precinct Stationhouse",
      background = "A cold, methodical investigator who has survived four administrations by serving whoever holds the purse strings in City Hall.",
      knownInformation = "Coordinates police operations at the harbor and issued the perimeter blackout order for 'Operation Lantern'.",
      conflictOfInterest = "On the monthly payroll of Greybridge Smelting to protect harbor transit.",
      trustScore = -20,
      isHostile = true,
      dialogueTree = mapOf(
        "root" to SourceDialogueNode(
          nodeKey = "root",
          prompt = "Inspector Reed looks up from a stack of arrest warrants under the green glass desk lamp. Smoke from his cigar curls toward the tin ceiling. 'Well, well. The Gazette's night hawk. You're a long way from the typewriter, ink-stained boy.'",
          options = listOf(
            DialogueOption(
              id = "opt_reed_lantern",
              text = "Inquire about 'Operation Lantern' and the dock perimeter order.",
              stance = DialogueStance.NEUTRAL_QUESTION,
              requiredEvidenceId = "ev_c1_police_memo",
              responseText = "Reed's eyes narrow into slits. 'Internal police operational business. If you print a word of that memo, editor, I'll have you in a holding cell for obstructing justice before the ink is dry.'",
              trustDelta = -10,
              timeCostMinutes = 20
            ),
            DialogueOption(
              id = "opt_reed_confront_alibi",
              text = "Challenge his alibi: 'You logged yourself at 5th and Main at 11:50 PM, but bridge toll records show your car crossing Iron Bridge toward Wharf 7!'",
              stance = DialogueStance.CHALLENGE_CONTRADICTION,
              requiredEvidenceId = "ev_c3_patrol_dispatch",
              responseText = "Reed's cigar pauses. His voice drops to a deadly whisper. 'You're playing a dangerous game, kid. Toll collectors make mistakes. The Gazette has a license to publish that can be revoked by the Mayor by 8 AM.'",
              trustDelta = -15,
              timeCostMinutes = 25
            ),
            DialogueOption(
              id = "opt_reed_end",
              text = "Tip your fedora and walk out.",
              stance = DialogueStance.END_INTERVIEW,
              responseText = "'Make sure you check under your car before turning the ignition,' Reed says smoothly.",
              timeCostMinutes = 5
            )
          )
        )
      )
    ),

    SourceCharacter(
      id = "src_alderman_voss",
      name = "Alderman Donald Voss",
      role = "City Council Chairman",
      affiliation = "Municipal Council / Voss Contracting",
      location = "The Greybridge Club (Private Lounge)",
      background = "Wealthy, impeccably tailored, and connected to the state governor. Controls municipal public works contracts and the port authority.",
      knownInformation = "Coordinates the titanium ore smuggling syndicate and the silencing of whistleblowers.",
      conflictOfInterest = "Direct recipient of Swiss bank wire transfers.",
      trustScore = -30,
      dialogueTree = mapOf(
        "root" to SourceDialogueNode(
          nodeKey = "root",
          prompt = "Alderman Voss sips single malt scotch in the leather armchair of the exclusive Greybridge Club. 'My dear night editor. Charles Henderson assured me tonight's edition would focus on the municipal flower show.'",
          options = listOf(
            DialogueOption(
              id = "opt_voss_inquire",
              text = "Ask about the titanium ore shipments at Warehouse 7.",
              stance = DialogueStance.NEUTRAL_QUESTION,
              responseText = "Voss smiles benignly. 'Scrap metal recycling for the post-war reconstruction, my friend. Greybridge is an industrial city. We make iron, not scandals.'",
              trustDelta = -5,
              timeCostMinutes = 25
            ),
            DialogueOption(
              id = "opt_voss_confront_ledger",
              text = "Present the Swiss bank wire transfer slip with his signature.",
              stance = DialogueStance.PRESENT_EVIDENCE,
              requiredEvidenceId = "ev_c5_bank_wire_slip",
              responseText = "Voss's smile vanishes. He sets down his glass with precision. 'You think this piece of paper will protect you? Henderson's family has shares in that very company. The Gazette belongs to us.'",
              trustDelta = -20,
              timeCostMinutes = 30
            ),
            DialogueOption(
              id = "opt_voss_end",
              text = "Conclude the interview.",
              stance = DialogueStance.END_INTERVIEW,
              responseText = "'Enjoy your printing deadline. It may be your last,' Voss murmurs.",
              timeCostMinutes = 5
            )
          )
        )
      )
    )
  )

  val allDeductions: List<EvidenceDeduction> = listOf(
    EvidenceDeduction(
      id = "ded_c1_prewritten_leak",
      evidenceAId = "ev_c1_future_paper",
      evidenceBId = "ev_c1_police_memo",
      deductionTitle = "Pre-Written Execution Narrative",
      deductionText = "The tomorrow-dated newspaper quotes confidential 4th Precinct radio dispatch codes from an operation planned for tonight. This proves Arthur Pendelton's murder was not a spontaneous crime, but a pre-meditated assassination coordinated between the police dispatchers and whoever ordered the linotype plates cast!",
      unlocksLeadId = "lead_c1_blackdog",
      unlocksQuestionForSourceId = "src_silas_thorne",
      unlocksStoryId = "story_c1_ghost_edition",
      credibilityBonus = 15
    ),
    EvidenceDeduction(
      id = "ded_c1_timecard_discrepancy",
      evidenceAId = "ev_c1_payroll",
      evidenceBId = "ev_c1_future_paper",
      deductionTitle = "Alive and In Hiding",
      deductionText = "Arthur Pendelton clocked out alive at 11:10 PM after receiving an emergency warning call, proving the 'midnight murder' reported in the tomorrow edition has not taken place yet! Arthur is actively evading his killers.",
      unlocksLeadId = "lead_c1_blackdog",
      credibilityBonus = 10
    ),
    EvidenceDeduction(
      id = "ded_c2_smuggled_ore",
      evidenceAId = "ev_c2_carbon_copy",
      evidenceBId = "ev_c2_dock_manifest",
      deductionTitle = "Titanium Contraband Pipeline",
      deductionText = "Julian Graves' hidden carbons match the cargo weights on Steamer Cynthia's manifest. Strategic titanium ore is being exported under the guise of municipal scrap iron with police commissioner sign-off.",
      unlocksStoryId = "story_c2_contraband_ore",
      credibilityBonus = 20
    ),
    EvidenceDeduction(
      id = "ded_c3_staged_crime_scene",
      evidenceAId = "ev_c3_streetcar_log",
      evidenceBId = "ev_c3_patrol_dispatch",
      deductionTitle = "Falsified Police Dispatch Log",
      deductionText = "Inspector Reed claimed to be on routine patrol at 5th and Main, but the transit block records prove his squad car crossed Iron Bridge to seal off Wharf 4 right before the hit.",
      unlocksStoryId = "story_c3_fabricated_alibi",
      credibilityBonus = 20
    ),
    EvidenceDeduction(
      id = "ded_c4_staged_industrial_accidents",
      evidenceAId = "ev_c4_parish_register",
      evidenceBId = "ev_c4_extortion_note",
      deductionTitle = "Systematic Union Assassinations",
      deductionText = "The parish death registry corroborates the extortion notes: three union leaders who planned a strike were murdered with garrotes before being thrown into molten slag to stage 'workplace accidents'.",
      unlocksStoryId = "story_c4_union_intimidation",
      credibilityBonus = 25
    ),
    EvidenceDeduction(
      id = "ded_c5_precinct_bribery",
      evidenceAId = "ev_c5_slush_ledger",
      evidenceBId = "ev_c5_bank_wire_slip",
      deductionTitle = "The Iron Slush Fund",
      deductionText = "Disbursement records tie the monthly $2,000 police payoffs directly to Alderman Voss's overseas accounts, proving the municipal government itself financed the suppression squad.",
      unlocksStoryId = "story_c5_slush_fund_exposed",
      credibilityBonus = 25
    ),
    EvidenceDeduction(
      id = "ded_c6_publisher_extortion",
      evidenceAId = "ev_c6_linotype_matrix",
      evidenceBId = "ev_c6_editors_memo",
      deductionTitle = "The Gazette's Betrayal",
      deductionText = "The brass linotype matrix was cast directly from Managing Editor Henderson's private office typewriter. The newspaper's own leadership conspired to frame Arthur Pendelton and suppress the truth.",
      unlocksStoryId = "story_c6_internal_sabotage",
      credibilityBonus = 30
    ),
    EvidenceDeduction(
      id = "ded_c7_syndicate_command",
      evidenceAId = "ev_c7_commissioner_order",
      evidenceBId = "ev_c5_slush_ledger",
      deductionTitle = "The Police Coup",
      deductionText = "Commissioner Cross's press seizure warrant is timed for 03:00 AM to prevent the morning public from ever seeing the financial audit. It is an unconstitutional coup against the free press.",
      unlocksStoryId = "story_c7_cross_conspiracy",
      credibilityBonus = 30
    ),
    EvidenceDeduction(
      id = "ded_c8_the_complete_truth",
      evidenceAId = "ev_c8_final_manifesto",
      evidenceBId = "ev_c7_commissioner_order",
      deductionTitle = "The Iron Syndicate Exposed",
      deductionText = "Every thread links together: the future-dated edition, the stolen ore, the murdered reporters, and the corrupt police. The complete charter provides unimpeachable legal evidence for federal indictment.",
      unlocksStoryId = "story_c8_unvarnished_expose",
      credibilityBonus = 50
    )
  )

  val allLeads: List<InvestigationLead> = listOf(
    InvestigationLead(
      id = "lead_c1_pressroom",
      chapterId = 1,
      title = "Subterranean Press Room",
      location = "Gazette Sub-Basement",
      description = "Inspect Rotary Press #2 and the molten lead Linotype casting pots where tomorrow's edition was printed.",
      timeCostMinutes = 30,
      unlocksEvidenceIds = listOf("ev_c1_taxi_receipt"),
      unlocksSourceId = "src_silas_thorne"
    ),
    InvestigationLead(
      id = "lead_c1_blackdog",
      chapterId = 1,
      title = "The Black Dog Tavern",
      location = "Canal Basin & Malt House",
      description = "Search for foreman Arthur Pendelton before the 4th Precinct hit squad intercepts him.",
      timeCostMinutes = 45,
      requiresEvidenceId = "ev_c1_future_paper",
      unlocksSourceId = "src_arthur_pendelton"
    ),
    InvestigationLead(
      id = "lead_c1_slagworks",
      chapterId = 1,
      title = "Vulcan Slagworks Gate 3",
      location = "River Docks Industrial Zone",
      description = "Interview the night gatekeeper and inspect Arthur Pendelton's abandoned locker.",
      timeCostMinutes = 45,
      unlocksEvidenceIds = listOf("ev_c1_payroll")
    ),

    // Chapter 2 leads
    InvestigationLead(
      id = "lead_c2_warehouse7",
      chapterId = 2,
      title = "Harbor Warehouse 7",
      location = "Berth 3 Cargo Basin",
      description = "Examine the unsealed crates marked 'scrap iron' under cover of the harbor fog.",
      timeCostMinutes = 60,
      unlocksEvidenceIds = listOf("ev_c2_dock_manifest")
    ),
    InvestigationLead(
      id = "lead_c2_graves_flat",
      chapterId = 2,
      title = "Julian Graves' Apartment",
      location = "14 St. Jude's Terrace",
      description = "Search the ransacked rooms of the missing journalist.",
      timeCostMinutes = 45,
      unlocksEvidenceIds = listOf("ev_c2_sister_letter")
    ),

    // Chapter 3 leads
    InvestigationLead(
      id = "lead_c3_car_depot",
      chapterId = 3,
      title = "Traction Co. Car Barns",
      location = "North Depot Yard",
      description = "Examine the transit conductor's logbooks for Route 14.",
      timeCostMinutes = 40,
      unlocksEvidenceIds = listOf("ev_c3_streetcar_log")
    ),
    InvestigationLead(
      id = "lead_c3_iron_bridge",
      chapterId = 3,
      title = "Iron Bridge Toll House",
      location = "Canal River Crossing",
      description = "Subpoena the municipal bridge toll register sheets from midnight.",
      timeCostMinutes = 40,
      unlocksEvidenceIds = listOf("ev_c3_toll_ticket")
    )
  )

  val allStories: List<NewspaperStory> = listOf(
    NewspaperStory(
      id = "story_c1_ghost_edition",
      chapterId = 1,
      headline = "GHOST EDITION EXPOSES POLICE AMBUSH PLOT",
      subHeadline = "Foundry Foreman Slain on Paper Hours Before Scheduled Execution",
      authorByline = "By Nora Vance & The Night Desk",
      fullArticleText = "GREYBRIDGE — In an unprecedented scandal shaking the foundations of City Hall, a pre-printed copy of tomorrow's Gazette was discovered on the press floor tonight, detailing the murder of Vulcan Slagworks foreman Arthur Pendelton hours before the event was to take place. Confidential police memos reveal 4th Precinct officers were ordered away from the docks to allow the assassination to proceed unhindered. Pendelton is currently in protective custody.",
      cautiousArticleText = "GREYBRIDGE — Irregularities in the Gazette press room were brought to light late this evening after unauthorized materials regarding an alleged waterfront altercation were cast into type. Police officials maintain routine patrols are in effect throughout the harbor district.",
      requiredEvidenceIds = listOf("ev_c1_future_paper", "ev_c1_police_memo"),
      verificationLevel = "Fully Verified (Double Sourced)",
      legalRisk = "High (Police Threat)",
      politicalImpact = "Massive public outrage against 4th Precinct; shields Arthur Pendelton from murder.",
      selectedStance = EditorialStance.DELAY_VERIFICATION,
      assignedSlot = StorySlot.LEAD_BANNER
    ),
    NewspaperStory(
      id = "story_c1_pendelton_threat",
      chapterId = 1,
      headline = "VULCAN FOREMAN FLEES AFTER MYSTERIOUS MIDNIGHT CALL",
      subHeadline = "Arthur Pendelton Disappears from Slagworks Shift; Foul Play Feared",
      authorByline = "By Staff Reporter",
      fullArticleText = "GREYBRIDGE — Arthur Pendelton, night foreman of Vulcan Slagworks, vanished from his post at 11:10 PM following an anonymous telephone call. Co-workers reported Pendelton appeared in grave distress. Police have issued a missing persons advisory.",
      cautiousArticleText = "GREYBRIDGE — Foundry officials confirmed a brief unauthorized absence of supervisory personnel at Vulcan Slagworks. Normal industrial operations remain undisturbed.",
      requiredEvidenceIds = listOf("ev_c1_payroll"),
      verificationLevel = "Single Source (Gate Log)",
      legalRisk = "Low",
      politicalImpact = "Moderate interest among industrial union workers.",
      selectedStance = EditorialStance.DELAY_VERIFICATION,
      assignedSlot = StorySlot.SECONDARY_COLUMN
    ),
    NewspaperStory(
      id = "story_c1_dock_curfew",
      chapterId = 1,
      headline = "4TH PRECINCT ENFORCES WATERFRONT CURFEW FOR 'SPECIAL DRILL'",
      subHeadline = "Harbor Merchants Complain of Sudden Cargo Stoppages",
      authorByline = "By City Wire",
      fullArticleText = "GREYBRIDGE — Beat patrols along River Street were placed on restricted standby tonight under orders from Inspector Thomas Reed. Merchants at Berths 1 through 6 were ordered to vacate piers until 06:00 AM.",
      cautiousArticleText = "GREYBRIDGE — Routine harbor security inspections were conducted overnight by local law enforcement to ensure waterfront safety.",
      requiredEvidenceIds = listOf("ev_c1_police_memo"),
      verificationLevel = "Official Document",
      legalRisk = "Negligible",
      politicalImpact = "Mild municipal notice.",
      selectedStance = EditorialStance.DELAY_VERIFICATION,
      assignedSlot = StorySlot.WIRE_SIDEBAR
    ),

    // Chapter 2
    NewspaperStory(
      id = "story_c2_contraband_ore",
      chapterId = 2,
      headline = "TITANIUM SMUGGLING RING EXPOSED AT WAREHOUSE 7",
      subHeadline = "Missing Reporter Graves' Secret Carbons Prove Port Authority Fraud",
      authorByline = "By Nora Vance",
      fullArticleText = "GREYBRIDGE — Strategic high-grade titanium ore destined for national defense has been illicitly diverted through Greybridge Harbor under fraudulent scrap iron manifests. Secret notes authored by missing reporter Julian Graves reveal a multimillion-dollar syndicate operating with city approval.",
      cautiousArticleText = "GREYBRIDGE — Questions have arisen regarding cargo manifest classifications at Berth 3 following discrepancies noted by waterfront auditors.",
      requiredEvidenceIds = listOf("ev_c2_carbon_copy", "ev_c2_dock_manifest"),
      verificationLevel = "Fully Verified",
      legalRisk = "Moderate",
      politicalImpact = "Directly challenges Port Authority Board.",
      selectedStance = EditorialStance.DELAY_VERIFICATION,
      assignedSlot = StorySlot.LEAD_BANNER
    ),

    // Chapter 8
    NewspaperStory(
      id = "story_c8_unvarnished_expose",
      chapterId = 8,
      headline = "THE COMPLETE CONSPIRACY: SYNDICATE EXPOSED",
      subHeadline = "Commissioner Cross, Alderman Voss, and Publisher Henderson Indicted by Facts",
      authorByline = "The Editorial Board of The Greybridge Gazette",
      fullArticleText = "GREYBRIDGE — Tonight, as the printing presses turn for the final edition under our custodianship, we present the unvarnished truth to the citizens of Greybridge. For five years, our city has been governed not by the rule of law, but by an Iron Syndicate comprising Police Commissioner Harlan Cross, Alderman Donald Voss, and our own managing publisher. We publish here the sworn manifests, the Swiss wire transfers, and the proof of murdered union organizers. Truth cannot be arrested.",
      cautiousArticleText = "GREYBRIDGE — The Greybridge Gazette places into the historical record findings from an eight-day investigation into municipal harbor contracts. We call upon the Governor and the Department of Justice for an immediate federal inquiry.",
      requiredEvidenceIds = listOf("ev_c8_final_manifesto"),
      verificationLevel = "Impeachable Federal Evidence",
      legalRisk = "Extreme (Press Raid Imminent)",
      politicalImpact = "Total overthrow of municipal corruption machine.",
      selectedStance = EditorialStance.DELAY_VERIFICATION,
      assignedSlot = StorySlot.LEAD_BANNER
    )
  )

  val timelineEvents: List<TimelineEvent> = listOf(
    TimelineEvent(
      id = "time_1",
      timeLabel = "10:15 PM",
      location = "City Hall Annex",
      actor = "Unknown Courier",
      eventSummary = "A passenger in a black trenchcoat takes Taxi #104 carrying a heavy wooden lockbox.",
      isVerified = true,
      linkedEvidenceId = "ev_c1_taxi_receipt"
    ),
    TimelineEvent(
      id = "time_2",
      timeLabel = "10:35 PM",
      location = "Gazette Alley",
      actor = "Silas Thorne",
      eventSummary = "Courier meets Silas Thorne at the press basement door, handing over handwritten copy.",
      isVerified = true,
      linkedEvidenceId = "ev_c1_future_paper"
    ),
    TimelineEvent(
      id = "time_3",
      timeLabel = "10:45 PM",
      location = "Vulcan Slagworks",
      actor = "Arthur Pendelton",
      eventSummary = "Arthur clocks in for night shift at Gate 3.",
      isVerified = true,
      linkedEvidenceId = "ev_c1_payroll"
    ),
    TimelineEvent(
      id = "time_4",
      timeLabel = "11:10 PM",
      location = "Vulcan Slagworks",
      actor = "Arthur Pendelton",
      eventSummary = "Arthur receives warning call at gatekeeper booth, flees to Black Dog Tavern.",
      isVerified = true,
      linkedEvidenceId = "ev_c1_payroll"
    ),
    TimelineEvent(
      id = "time_5",
      timeLabel = "11:30 PM",
      location = "River District",
      actor = "Inspector Thomas Reed",
      eventSummary = "Police perimeter clears Wharf Alleys under 'Operation Lantern'.",
      isVerified = true,
      linkedEvidenceId = "ev_c1_police_memo"
    ),
    TimelineEvent(
      id = "time_6",
      timeLabel = "00:15 AM (Scheduled)",
      location = "Wharf Alley 4",
      actor = "Hit Squad",
      eventSummary = "Scheduled time for Arthur Pendelton's planned assassination.",
      isVerified = false,
      linkedEvidenceId = "ev_c1_future_paper"
    )
  )
}
