package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 1940s Vintage Newspaper Palette
val PaperIvory = Color(0xFFF7F3E8)
val PaperAged = Color(0xFFEFE9DA)
val PaperSurface = Color(0xFFF1EBDC)
val InkBlack = Color(0xFF181615)
val InkCharcoal = Color(0xFF2C2825)
val InkMuted = Color(0xFF5E564F)
val SepiaBrown = Color(0xFF754E2E)
val SepiaLight = Color(0xFFA67C52)
val SepiaFaint = Color(0xFFD9CCA3)
val StampRed = Color(0xFF9E2A2B)
val StampGreen = Color(0xFF2D5A27)
val LampGreen = Color(0xFF1E3F20)
val RuleDivider = Color(0xFF3D3732)
val RuleLight = Color(0xFFC7BDA9)

// Darkroom / Night Newsroom Palette
val DarkroomBase = Color(0xFF141210)
val DarkroomSurface = Color(0xFF1E1A17)
val DarkroomElevated = Color(0xFF2A2420)
val DarkroomText = Color(0xFFE8E2D5)
val DarkroomTextMuted = Color(0xFFA89F93)
val DarkroomSepia = Color(0xFFC49A6C)
val DarkroomRule = Color(0xFF423B34)
