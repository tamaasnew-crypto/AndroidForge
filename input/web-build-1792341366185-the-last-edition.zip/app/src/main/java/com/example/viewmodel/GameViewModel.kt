package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameContentRepository
import com.example.data.SaveManager
import com.example.model.*
import com.example.ui.components.NavDestination
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class GameUiState(
  val currentDestination: NavDestination = NavDestination.FRONT_PAGE,
  val currentChapter: Chapter = GameContentRepository.chapters[0],
  val elapsedMinutes: Int = 0,
  val maxMinutes: Int = 240,
  val publicTrust: Int = 65,
  val policeHeat: Int = 20,
  val legalRisk: Int = 15,
  val availableEvidence: List<EvidenceItem> = emptyList(),
  val activeLeads: List<InvestigationLead> = emptyList(),
  val activeSources: List<SourceCharacter> = emptyList(),
  val availableStories: List<NewspaperStory> = emptyList(),
  val printedEditions: List<PrintedEdition> = emptyList(),
  val journalEntries: List<JournalEntry> = emptyList(),
  val completedDeductionIds: Set<String> = emptySet(),
  val completedChapterIds: Set<Int> = emptySet(),
  // Dialog / Sub-state
  val selectedEvidence: EvidenceItem? = null,
  val compareEvidenceA: EvidenceItem? = null,
  val compareEvidenceB: EvidenceItem? = null,
  val lastDeductionResult: EvidenceDeduction? = null,
  val deductionMismatchMessage: String? = null,
  val activeInterviewSource: SourceCharacter? = null,
  val activeDialogueNodeKey: String = "root",
  val interviewHistory: List<Pair<String, String>> = emptyList(), // (Speaker, Text)
  val storyToEdit: NewspaperStory? = null,
  val chapterResolution: ChapterResolution? = null,
  val saveSlotList: List<SaveSlotSummary> = emptyList(),
  val bannerNotification: String? = null,
  // Tutorial State
  val isTutorialActive: Boolean = true,
  val tutorialStep: Int = 1,
  val tutorialCompleted: Boolean = false,
  // Settings
  val settings: GameSettings = GameSettings()
) {
  val minutesRemaining: Int
    get() = (maxMinutes - elapsedMinutes).coerceAtLeast(0)

  val clockFormatted: String
    get() {
      val totalMinutes = 23 * 60 + elapsedMinutes
      val hour24 = (totalMinutes / 60) % 24
      val minute = totalMinutes % 60
      val hour12 = if (hour24 == 0) 12 else if (hour24 > 12) hour24 - 12 else hour24
      val amPm = if (hour24 >= 12 && hour24 < 24) "PM" else "AM"
      return String.format("%02d:%02d %s", hour12, minute, amPm)
    }

  val isDeadlineReached: Boolean
    get() = elapsedMinutes >= maxMinutes
}

class GameViewModel(application: Application) : AndroidViewModel(application) {

  private val saveManager = SaveManager(application)

  private val _uiState = MutableStateFlow(GameUiState())
  val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

  init {
    initializeOrLoadGame()
  }

  private fun initializeOrLoadGame() {
    val autoSave = saveManager.loadGame(0)
    if (autoSave != null) {
      applyLoadedState(autoSave)
    } else {
      startNewCampaign(chapterId = 1)
    }
    refreshSaveSlots()
  }

  fun startNewCampaign(chapterId: Int = 1) {
    val chapter = GameContentRepository.chapters.find { it.id == chapterId } ?: GameContentRepository.chapters[0]
    val evidence = GameContentRepository.allEvidence.filter { it.chapterId <= chapterId }
    val leads = GameContentRepository.allLeads.filter { it.chapterId <= chapterId }
    val sources = GameContentRepository.allSources
    val stories = GameContentRepository.allStories.filter { it.chapterId <= chapterId }

    val initialJournal = listOf(
      JournalEntry(
        id = "j_init_${System.currentTimeMillis()}",
        timestampLabel = "11:00 PM",
        text = "Shift begins at The Greybridge Gazette. A future-dated copy of tomorrow's paper found on Press #2.",
        chapterId = chapterId,
        isImportant = true
      )
    )

    _uiState.value = GameUiState(
      currentChapter = chapter,
      elapsedMinutes = 0,
      publicTrust = 65,
      policeHeat = 20,
      legalRisk = 15,
      availableEvidence = evidence,
      activeLeads = leads,
      activeSources = sources,
      availableStories = stories,
      journalEntries = initialJournal,
      isTutorialActive = chapterId == 1,
      tutorialStep = 1,
      tutorialCompleted = false
    )

    autoSaveCurrentGame()
  }

  fun navigateTo(destination: NavDestination) {
    _uiState.value = _uiState.value.copy(currentDestination = destination)

    // Tutorial step check
    if (_uiState.value.isTutorialActive) {
      if (destination == NavDestination.CASE_FILES && _uiState.value.tutorialStep == 2) {
        advanceTutorialStep(3)
      } else if (destination == NavDestination.SOURCES && _uiState.value.tutorialStep == 7) {
        advanceTutorialStep(8)
      } else if (destination == NavDestination.FRONT_PAGE && _uiState.value.tutorialStep == 9) {
        advanceTutorialStep(9)
      }
    }
  }

  fun advanceTime(minutes: Int, reason: String) {
    val current = _uiState.value
    val newElapsed = (current.elapsedMinutes + minutes).coerceAtMost(current.maxMinutes)
    val clock = current.clockFormatted

    val newJournal = current.journalEntries + JournalEntry(
      id = "j_${System.currentTimeMillis()}",
      timestampLabel = clock,
      text = "$reason (Elapsed ${minutes}m)",
      chapterId = current.currentChapter.id
    )

    _uiState.value = current.copy(
      elapsedMinutes = newElapsed,
      journalEntries = newJournal
    )

    if (newElapsed >= current.maxMinutes) {
      showNotification("PRESS DEADLINE REACHED! All presses must roll immediately.")
    }

    autoSaveCurrentGame()
  }

  // --- EVIDENCE & DEDUCTIONS ---

  fun openEvidenceDetail(item: EvidenceItem) {
    advanceTime(5, "Examined ${item.title}")
    _uiState.value = _uiState.value.copy(selectedEvidence = item)

    if (_uiState.value.isTutorialActive) {
      if (item.id == "ev_c1_future_paper" && _uiState.value.tutorialStep == 3) {
        advanceTutorialStep(4)
      } else if (item.id == "ev_c1_police_memo" && _uiState.value.tutorialStep == 4) {
        advanceTutorialStep(5)
      }
    }
  }

  fun closeEvidenceDetail() {
    _uiState.value = _uiState.value.copy(selectedEvidence = null)
  }

  fun updateEvidenceStatus(evidenceId: String, newStatus: EvidenceStatus) {
    val updated = _uiState.value.availableEvidence.map {
      if (it.id == evidenceId) it.copy(status = newStatus) else it
    }
    _uiState.value = _uiState.value.copy(
      availableEvidence = updated,
      selectedEvidence = _uiState.value.selectedEvidence?.let { if (it.id == evidenceId) it.copy(status = newStatus) else it }
    )
    showNotification("Evidence marked as ${newStatus.label}")
    autoSaveCurrentGame()
  }

  fun updateEvidenceNotes(evidenceId: String, notes: String) {
    val updated = _uiState.value.availableEvidence.map {
      if (it.id == evidenceId) it.copy(userNotes = notes) else it
    }
    _uiState.value = _uiState.value.copy(
      availableEvidence = updated,
      selectedEvidence = _uiState.value.selectedEvidence?.let { if (it.id == evidenceId) it.copy(userNotes = notes) else it }
    )
    autoSaveCurrentGame()
  }

  fun setCompareItemA(item: EvidenceItem?) {
    _uiState.value = _uiState.value.copy(compareEvidenceA = item, deductionMismatchMessage = null)
  }

  fun setCompareItemB(item: EvidenceItem?) {
    _uiState.value = _uiState.value.copy(compareEvidenceB = item, deductionMismatchMessage = null)
  }

  fun executeCompareAndDeduce() {
    val a = _uiState.value.compareEvidenceA ?: return
    val b = _uiState.value.compareEvidenceB ?: return

    if (a.id == b.id) {
      _uiState.value = _uiState.value.copy(deductionMismatchMessage = "Select two distinct evidence items to compare.")
      return
    }

    advanceTime(15, "Compared ${a.title} with ${b.title}")

    // Check repository deductions
    val deduction = GameContentRepository.allDeductions.find {
      (it.evidenceAId == a.id && it.evidenceBId == b.id) ||
      (it.evidenceAId == b.id && it.evidenceBId == a.id)
    }

    if (deduction != null) {
      val isNew = !_uiState.value.completedDeductionIds.contains(deduction.id)
      val updatedDeductions = _uiState.value.completedDeductionIds + deduction.id
      val updatedTrust = (_uiState.value.publicTrust + deduction.credibilityBonus).coerceAtMost(100)

      // Unlock leads or stories if applicable
      var updatedLeads = _uiState.value.activeLeads
      if (deduction.unlocksLeadId != null) {
        val leadToUnlock = GameContentRepository.allLeads.find { it.id == deduction.unlocksLeadId }
        if (leadToUnlock != null && updatedLeads.none { it.id == leadToUnlock.id }) {
          updatedLeads = updatedLeads + leadToUnlock
        }
      }

      var updatedStories = _uiState.value.availableStories
      if (deduction.unlocksStoryId != null) {
        val storyToUnlock = GameContentRepository.allStories.find { it.id == deduction.unlocksStoryId }
        if (storyToUnlock != null && updatedStories.none { it.id == storyToUnlock.id }) {
          updatedStories = updatedStories + storyToUnlock
        }
      }

      // Mark evidence as verified
      val updatedEvidence = _uiState.value.availableEvidence.map {
        if (it.id == a.id || it.id == b.id) it.copy(status = EvidenceStatus.VERIFIED) else it
      }

      val newJournal = _uiState.value.journalEntries + JournalEntry(
        id = "j_ded_${System.currentTimeMillis()}",
        timestampLabel = _uiState.value.clockFormatted,
        text = "DEDUCTION MADE: ${deduction.deductionTitle}",
        chapterId = _uiState.value.currentChapter.id,
        isImportant = true
      )

      _uiState.value = _uiState.value.copy(
        completedDeductionIds = updatedDeductions,
        publicTrust = updatedTrust,
        activeLeads = updatedLeads,
        availableStories = updatedStories,
        availableEvidence = updatedEvidence,
        lastDeductionResult = deduction,
        deductionMismatchMessage = null,
        journalEntries = newJournal
      )

      showNotification("BREAKTHROUGH: ${deduction.deductionTitle}")

      if (_uiState.value.isTutorialActive && _uiState.value.tutorialStep == 5) {
        advanceTutorialStep(6)
      }
    } else {
      _uiState.value = _uiState.value.copy(
        deductionMismatchMessage = "No direct contradiction or deduction found between these two documents. Consider examining dates, sources, or vehicle logs.",
        lastDeductionResult = null
      )
    }

    autoSaveCurrentGame()
  }

  fun dismissDeductionResult() {
    _uiState.value = _uiState.value.copy(lastDeductionResult = null)
    if (_uiState.value.isTutorialActive && _uiState.value.tutorialStep == 6) {
      advanceTutorialStep(7)
    }
  }

  // --- LEADS & INVESTIGATION ---

  fun investigateLead(lead: InvestigationLead) {
    if (lead.isCompleted) return

    advanceTime(lead.timeCostMinutes, "Investigated ${lead.title} at ${lead.location}")

    val updatedLeads = _uiState.value.activeLeads.map {
      if (it.id == lead.id) it.copy(isCompleted = true) else it
    }

    // Unlocked evidence
    val newEvidenceItems = GameContentRepository.allEvidence.filter { lead.unlocksEvidenceIds.contains(it.id) }
    val currentIds = _uiState.value.availableEvidence.map { it.id }.toSet()
    val additions = newEvidenceItems.filter { !currentIds.contains(it.id) }
    val updatedEvidence = _uiState.value.availableEvidence + additions

    val newJournal = _uiState.value.journalEntries + JournalEntry(
      id = "j_lead_${System.currentTimeMillis()}",
      timestampLabel = _uiState.value.clockFormatted,
      text = "Lead Investigated: ${lead.title}. Found ${additions.size} new records.",
      chapterId = _uiState.value.currentChapter.id
    )

    _uiState.value = _uiState.value.copy(
      activeLeads = updatedLeads,
      availableEvidence = updatedEvidence,
      journalEntries = newJournal
    )

    showNotification("Investigation completed at ${lead.location} (+${additions.size} evidence)")
    autoSaveCurrentGame()
  }

  // --- SOURCES & INTERVIEWS ---

  fun startInterview(source: SourceCharacter) {
    val initialHistory = listOf(
      "Narrative" to "You pull up a wooden chair across from ${source.name} at ${source.location}.",
      source.name to (source.dialogueTree[source.defaultDialogueKey]?.prompt ?: "What do you want?")
    )

    _uiState.value = _uiState.value.copy(
      activeInterviewSource = source,
      activeDialogueNodeKey = source.defaultDialogueKey,
      interviewHistory = initialHistory
    )
  }

  fun selectDialogueOption(option: DialogueOption) {
    val source = _uiState.value.activeInterviewSource ?: return

    advanceTime(option.timeCostMinutes, "Interviewed ${source.name} (${option.stance.label})")

    val newTrust = (source.trustScore + option.trustDelta).coerceIn(-100, 100)
    val updatedSource = source.copy(
      trustScore = newTrust,
      interviewCount = source.interviewCount + 1
    )

    // Unlocks from interview
    var updatedEvidence = _uiState.value.availableEvidence
    if (option.revealsEvidenceId != null) {
      val found = GameContentRepository.allEvidence.find { it.id == option.revealsEvidenceId }
      if (found != null && updatedEvidence.none { it.id == found.id }) {
        updatedEvidence = updatedEvidence + found
        showNotification("NEW EVIDENCE UNLOCKED: ${found.title}")
      }
    }

    var updatedLeads = _uiState.value.activeLeads
    if (option.revealsLeadId != null) {
      val foundLead = GameContentRepository.allLeads.find { it.id == option.revealsLeadId }
      if (foundLead != null && updatedLeads.none { it.id == foundLead.id }) {
        updatedLeads = updatedLeads + foundLead
        showNotification("NEW LEAD UNCOVERED: ${foundLead.title}")
      }
    }

    val newHistory = _uiState.value.interviewHistory + listOf(
      "You" to "[${option.stance.label}] ${option.text}",
      source.name to option.responseText
    )

    val nextNodeKey = option.nextDialogueKey ?: _uiState.value.activeDialogueNodeKey

    // Update in sources list
    val updatedSources = _uiState.value.activeSources.map {
      if (it.id == source.id) updatedSource else it
    }

    _uiState.value = _uiState.value.copy(
      activeInterviewSource = updatedSource,
      activeDialogueNodeKey = nextNodeKey,
      interviewHistory = newHistory,
      availableEvidence = updatedEvidence,
      activeLeads = updatedLeads,
      activeSources = updatedSources
    )

    if (option.stance == DialogueStance.CHALLENGE_CONTRADICTION && _uiState.value.isTutorialActive && _uiState.value.tutorialStep == 8) {
      advanceTutorialStep(9)
    }

    autoSaveCurrentGame()
  }

  fun endInterview() {
    _uiState.value = _uiState.value.copy(activeInterviewSource = null)
  }

  // --- EDITORIAL & FRONT PAGE ---

  fun openStoryEditor(story: NewspaperStory) {
    _uiState.value = _uiState.value.copy(storyToEdit = story)
  }

  fun closeStoryEditor() {
    _uiState.value = _uiState.value.copy(storyToEdit = null)
  }

  fun updateStoryDecision(storyId: String, stance: EditorialStance, slot: StorySlot?) {
    val updated = _uiState.value.availableStories.map { story ->
      if (story.id == storyId) {
        story.copy(selectedStance = stance, assignedSlot = slot)
      } else if (slot != null && story.assignedSlot == slot) {
        // Clear assignment from other story in that slot
        story.copy(assignedSlot = null)
      } else {
        story
      }
    }

    _uiState.value = _uiState.value.copy(
      availableStories = updated,
      storyToEdit = null
    )

    showNotification("Editorial stance set: ${stance.label}")

    if (_uiState.value.isTutorialActive && _uiState.value.tutorialStep == 9 && slot == StorySlot.LEAD_BANNER) {
      advanceTutorialStep(10)
    }

    autoSaveCurrentGame()
  }

  fun printNewspaperEdition() {
    val stories = _uiState.value.availableStories
    val leadStory = stories.find { it.assignedSlot == StorySlot.LEAD_BANNER }
    val columnStory = stories.find { it.assignedSlot == StorySlot.SECONDARY_COLUMN }
    val wireStory = stories.find { it.assignedSlot == StorySlot.WIRE_SIDEBAR }

    val leadHeadline = leadStory?.headline ?: "MIDNIGHT SILENCE OVER INDUSTRIAL DISTRICT"
    val leadBody = when (leadStory?.selectedStance) {
      EditorialStance.PUBLISH_FULL -> leadStory.fullArticleText
      EditorialStance.PUBLISH_CAUTIOUS -> leadStory.cautiousArticleText
      else -> "No verified lead story submitted before press deadline. Printing wire reports."
    }

    val columnHeadline = columnStory?.headline ?: "City Hall Announces Annual Budget Review"
    val columnBody = columnStory?.let {
      if (it.selectedStance == EditorialStance.PUBLISH_FULL) it.fullArticleText else it.cautiousArticleText
    } ?: "Municipal officials confirmed preparations for the winter district session."

    val sidebarHeadline = wireStory?.headline ?: "Harbor Shipping Notice"
    val sidebarBody = wireStory?.let {
      if (it.selectedStance == EditorialStance.PUBLISH_FULL) it.fullArticleText else it.cautiousArticleText
    } ?: "Standard freighter transit across Berth 3 proceeded on scheduled tidal drift."

    // Calculate outcomes based on player decisions
    var trustDelta = 0
    var heatDelta = 0
    var riskDelta = 0

    if (leadStory?.selectedStance == EditorialStance.PUBLISH_FULL) {
      trustDelta += 15
      heatDelta += 25
      riskDelta += 20
    } else if (leadStory?.selectedStance == EditorialStance.PUBLISH_CAUTIOUS) {
      trustDelta += 8
      heatDelta += 5
      riskDelta += 5
    }

    val newTrust = (_uiState.value.publicTrust + trustDelta).coerceIn(0, 100)
    val newHeat = (_uiState.value.policeHeat + heatDelta).coerceIn(0, 100)
    val newRisk = (_uiState.value.legalRisk + riskDelta).coerceIn(0, 100)

    val edition = PrintedEdition(
      editionNumber = _uiState.value.printedEditions.size + 1,
      dateString = _uiState.value.currentChapter.historicalDate,
      editionTitle = "Issue #${280 + _uiState.value.printedEditions.size} • Final Night Run",
      leadHeadline = leadHeadline,
      leadBody = leadBody,
      columnHeadline = columnHeadline,
      columnBody = columnBody,
      sidebarHeadline = sidebarHeadline,
      sidebarBody = sidebarBody,
      publicTrustScore = newTrust,
      policePressureScore = newHeat,
      legalExposureScore = newRisk,
      editorialSummary = "The presses completed their run of 40,000 copies at 03:00 AM. Bundles hit newsstands across Greybridge at dawn."
    )

    val resolution = ChapterResolution(
      chapterId = _uiState.value.currentChapter.id,
      wasDeadlineMet = _uiState.value.elapsedMinutes <= _uiState.value.maxMinutes,
      headlineChosen = leadHeadline,
      publicTrustDelta = trustDelta,
      policeHeatDelta = heatDelta,
      narrativeEpilogue = "By 6:00 AM, dockworkers, factory machinists, and patrolmen held damp copies of The Greybridge Gazette. Your bold editorial decision broke the conspiracy wide open. Arthur Pendelton escaped to safety, and the Grand Jury has issued emergency subpoenas.",
      unlockedNextChapterId = if (_uiState.value.currentChapter.id < 8) _uiState.value.currentChapter.id + 1 else null
    )

    val updatedPrinted = _uiState.value.printedEditions + edition
    val updatedCompleted = _uiState.value.completedChapterIds + _uiState.value.currentChapter.id

    _uiState.value = _uiState.value.copy(
      printedEditions = updatedPrinted,
      publicTrust = newTrust,
      policeHeat = newHeat,
      legalRisk = newRisk,
      chapterResolution = resolution,
      completedChapterIds = updatedCompleted,
      isTutorialActive = false,
      tutorialCompleted = true
    )

    autoSaveCurrentGame()
  }

  fun advanceToNextChapter(nextChapterId: Int) {
    _uiState.value = _uiState.value.copy(chapterResolution = null)
    startNewCampaign(chapterId = nextChapterId)
  }

  fun dismissResolution() {
    _uiState.value = _uiState.value.copy(chapterResolution = null)
  }

  // --- TUTORIAL PROGRESSION ---

  fun advanceTutorialStep(nextStep: Int) {
    if (!_uiState.value.isTutorialActive) return

    val completed = nextStep > 10
    _uiState.value = _uiState.value.copy(
      tutorialStep = nextStep,
      tutorialCompleted = completed,
      isTutorialActive = !completed
    )

    if (completed) {
      showNotification("Tutorial Complete! You have mastered the Night Editor Desk.")
    }

    autoSaveCurrentGame()
  }

  fun dismissTutorial() {
    _uiState.value = _uiState.value.copy(isTutorialActive = false)
    autoSaveCurrentGame()
  }

  fun restartTutorial() {
    _uiState.value = _uiState.value.copy(
      isTutorialActive = true,
      tutorialStep = 1,
      tutorialCompleted = false,
      currentDestination = NavDestination.FRONT_PAGE
    )
    autoSaveCurrentGame()
  }

  // --- SAVE & LOAD ---

  fun saveGameToSlot(slotIndex: Int) {
    val current = _uiState.value
    val data = GameSaveData(
      currentChapterId = current.currentChapter.id,
      elapsedNightMinutes = current.elapsedMinutes,
      publicTrustScore = current.publicTrust,
      policeHeatScore = current.policeHeat,
      legalRiskScore = current.legalRisk,
      unlockedEvidenceIds = current.availableEvidence.map { it.id },
      evidenceStatuses = current.availableEvidence.associate { it.id to it.status.name },
      evidenceNotes = current.availableEvidence.filter { it.userNotes.isNotEmpty() }.associate { it.id to it.userNotes },
      unlockedLeadIds = current.activeLeads.map { it.id },
      completedLeadIds = current.activeLeads.filter { it.isCompleted }.map { it.id },
      sourceTrustScores = current.activeSources.associate { it.id to it.trustScore },
      storyDecisions = current.availableStories.associate { it.id to it.selectedStance.name },
      storySlotAssignments = current.availableStories.filter { it.assignedSlot != null }.associate { it.id to it.assignedSlot!!.name },
      completedDeductionIds = current.completedDeductionIds.toList(),
      journalEntries = current.journalEntries,
      printedEditions = current.printedEditions,
      completedChapterIds = current.completedChapterIds.toList(),
      isTutorialActive = current.isTutorialActive,
      tutorialStep = current.tutorialStep,
      tutorialCompleted = current.tutorialCompleted
    )

    saveManager.saveGame(slotIndex, data)
    refreshSaveSlots()
    showNotification(if (slotIndex == 0) "Auto-saved" else "Game saved to Slot $slotIndex")
  }

  fun loadGameFromSlot(slotIndex: Int) {
    val data = saveManager.loadGame(slotIndex)
    if (data != null) {
      applyLoadedState(data)
      showNotification("Loaded Save Slot $slotIndex")
    } else {
      showNotification("Failed to load save slot.")
    }
  }

  fun deleteSaveSlot(slotIndex: Int) {
    saveManager.deleteSlot(slotIndex)
    refreshSaveSlots()
    showNotification("Deleted Slot $slotIndex")
  }

  private fun autoSaveCurrentGame() {
    viewModelScope.launch {
      saveGameToSlot(0)
    }
  }

  private fun refreshSaveSlots() {
    _uiState.value = _uiState.value.copy(saveSlotList = saveManager.listSaveSlots())
  }

  private fun applyLoadedState(data: GameSaveData) {
    val chapter = GameContentRepository.chapters.find { it.id == data.currentChapterId } ?: GameContentRepository.chapters[0]

    val evidence = GameContentRepository.allEvidence.filter {
      data.unlockedEvidenceIds.contains(it.id) || it.chapterId <= data.currentChapterId
    }.map { item ->
      val stName = data.evidenceStatuses[item.id]
      val status = if (stName != null) EvidenceStatus.valueOf(stName) else item.status
      val notes = data.evidenceNotes[item.id] ?: item.userNotes
      item.copy(status = status, userNotes = notes)
    }

    val leads = GameContentRepository.allLeads.filter {
      data.unlockedLeadIds.contains(it.id) || it.chapterId <= data.currentChapterId
    }.map { lead ->
      val completed = data.completedLeadIds.contains(lead.id)
      lead.copy(isCompleted = completed)
    }

    val sources = GameContentRepository.allSources.map { src ->
      val trust = data.sourceTrustScores[src.id] ?: src.trustScore
      src.copy(trustScore = trust)
    }

    val stories = GameContentRepository.allStories.filter { it.chapterId <= data.currentChapterId }.map { story ->
      val stanceName = data.storyDecisions[story.id]
      val stance = if (stanceName != null) EditorialStance.valueOf(stanceName) else story.selectedStance
      val slotName = data.storySlotAssignments[story.id]
      val slot = if (slotName != null) StorySlot.valueOf(slotName) else story.assignedSlot
      story.copy(selectedStance = stance, assignedSlot = slot)
    }

    _uiState.value = GameUiState(
      currentChapter = chapter,
      elapsedMinutes = data.elapsedNightMinutes,
      publicTrust = data.publicTrustScore,
      policeHeat = data.policeHeatScore,
      legalRisk = data.legalRiskScore,
      availableEvidence = evidence,
      activeLeads = leads,
      activeSources = sources,
      availableStories = stories,
      printedEditions = data.printedEditions,
      journalEntries = data.journalEntries,
      completedDeductionIds = data.completedDeductionIds.toSet(),
      completedChapterIds = data.completedChapterIds.toSet(),
      isTutorialActive = data.isTutorialActive,
      tutorialStep = data.tutorialStep,
      tutorialCompleted = data.tutorialCompleted
    )
  }

  // --- SETTINGS ---

  fun updateSettings(newSettings: GameSettings) {
    _uiState.value = _uiState.value.copy(settings = newSettings)
  }

  fun showNotification(msg: String) {
    _uiState.value = _uiState.value.copy(bannerNotification = msg)
  }

  fun dismissNotification() {
    _uiState.value = _uiState.value.copy(bannerNotification = null)
  }
}
