package com.example.model

data class InvestigationLead(
  val id: String,
  val chapterId: Int,
  val title: String,
  val location: String,
  val description: String,
  val timeCostMinutes: Int = 30,
  val requiresEvidenceId: String? = null,
  val unlocksEvidenceIds: List<String> = emptyList(),
  val unlocksSourceId: String? = null,
  val isCompleted: Boolean = false
)

data class Chapter(
  val id: Int,
  val title: String,
  val subtitle: String,
  val historicalDate: String,
  val deadlineClockTime: String, // e.g. "03:00 AM"
  val totalNightMinutes: Int = 240, // 11:00 PM to 03:00 AM
  val briefSummary: String,
  val narrativeIntro: String,
  val initialEvidenceIds: List<String>,
  val initialLeadIds: List<String>,
  val initialSourceIds: List<String>,
  val initialStoryIds: List<String>,
  val keyDeductionId: String
)

data class ChapterResolution(
  val chapterId: Int,
  val wasDeadlineMet: Boolean,
  val headlineChosen: String,
  val publicTrustDelta: Int,
  val policeHeatDelta: Int,
  val narrativeEpilogue: String,
  val unlockedNextChapterId: Int?
)
