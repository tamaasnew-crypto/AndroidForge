package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.StampBadge
import com.example.ui.components.VintageButton
import com.example.ui.theme.CourierFontFamily
import com.example.ui.theme.PlayfairFontFamily
import com.example.ui.theme.StampRed

data class TutorialInstruction(
  val stepNumber: Int,
  val title: String,
  val instructions: String,
  val buttonHint: String? = null
)

val tutorialSteps = listOf(
  TutorialInstruction(
    stepNumber = 1,
    title = "Welcome to the Night Shift",
    instructions = "You are the night editor of The Greybridge Gazette. A fresh copy of tomorrow's paper was found on the press floor describing a murder that hasn't happened yet.",
    buttonHint = "Tap Case Files below to examine the evidence."
  ),
  TutorialInstruction(
    stepNumber = 2,
    title = "Open Case Files Drawer",
    instructions = "Head to CASE FILES in the bottom navigation to inspect the evidence collected from the press floor and police bureau.",
    buttonHint = "Switch to Case Files tab."
  ),
  TutorialInstruction(
    stepNumber = 3,
    title = "Examine 'The Tomorrow Gazette'",
    instructions = "Tap on 'The Tomorrow Gazette (Oct 19 Issue)' in the Case Files to inspect its text, coroner quotes, and notched slug signature.",
    buttonHint = "Tap on The Tomorrow Gazette."
  ),
  TutorialInstruction(
    stepNumber = 4,
    title = "Examine 'Confidential Police Memo'",
    instructions = "Now tap on 'Confidential Police Memo #44-B' to read the leaked directive clearing beat patrols from the harbor alleys.",
    buttonHint = "Tap on Confidential Police Memo."
  ),
  TutorialInstruction(
    stepNumber = 5,
    title = "Cross-Reference Contradictions",
    instructions = "Switch to the 'Compare & Deduce' tab in Case Files. Select both documents into Slot A and Slot B, then hit 'Cross-Reference & Form Deduction'.",
    buttonHint = "Compare the two records."
  ),
  TutorialInstruction(
    stepNumber = 6,
    title = "Review Breakthrough Deduction",
    instructions = "Notice how the pre-written police dispatch codes expose the plot. Dismiss the deduction modal to unlock new leads and source questions.",
    buttonHint = "Dismiss deduction modal."
  ),
  TutorialInstruction(
    stepNumber = 7,
    title = "Interrogate Linotype Operator",
    instructions = "Navigate to the SOURCES desk. Select Silas Thorne to find out how the tomorrow plates got onto the rotary press.",
    buttonHint = "Head to Sources tab."
  ),
  TutorialInstruction(
    stepNumber = 8,
    title = "Challenge Inconsistency",
    instructions = "In the interview with Silas Thorne, select the 'Challenge Inconsistency' or 'Present Evidence' stance to break his silence and learn where Arthur is hiding.",
    buttonHint = "Choose Challenge Inconsistency."
  ),
  TutorialInstruction(
    stepNumber = 9,
    title = "Assign Front Page Headline",
    instructions = "Return to FRONT PAGE. Tap on 'GHOST EDITION EXPOSES POLICE AMBUSH PLOT' and assign it to the Lead Banner slot with 'Publish Full Exposé'.",
    buttonHint = "Assign Lead Banner story."
  ),
  TutorialInstruction(
    stepNumber = 10,
    title = "Roll the Presses",
    instructions = "Everything is set! Tap 'Lock Plates & Roll Presses' on the Front Page to print tonight's edition, expose the ambush, and save Arthur Pendelton's life!",
    buttonHint = "Tap Roll Presses."
  )
)

@Composable
fun TutorialBanner(
  step: Int,
  onDismissTutorial: () -> Unit,
  modifier: Modifier = Modifier
) {
  val currentInstruction = tutorialSteps.find { it.stepNumber == step } ?: return

  Card(
    shape = MaterialTheme.shapes.extraSmall,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = modifier
      .fillMaxWidth()
      .border(1.5.dp, MaterialTheme.colorScheme.primary)
      .testTag("tutorial_banner")
  ) {
    Column(modifier = Modifier.padding(10.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          StampBadge(text = "TUTORIAL: STEP $step/10", color = StampRed)
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "THE FIRST NIGHT SHIFT",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = CourierFontFamily,
            color = MaterialTheme.colorScheme.secondary
          )
        }
        IconButton(
          onClick = onDismissTutorial,
          modifier = Modifier.size(24.dp).testTag("dismiss_tutorial_icon")
        ) {
          Icon(Icons.Filled.Close, contentDescription = "Dismiss Tutorial", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = currentInstruction.title,
        style = MaterialTheme.typography.titleSmall,
        fontFamily = PlayfairFontFamily,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = currentInstruction.instructions,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurface
      )

      if (currentInstruction.buttonHint != null) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "OBJECTIVE: " + currentInstruction.buttonHint,
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary,
          fontSize = 9.sp
        )
      }
    }
  }
}
