package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameContentRepository
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.GameUiState

enum class ArchiveTab(val label: String) {
  PRINTED_EDITIONS("Past Editions"),
  JOURNAL("Night Journal"),
  CHAPTERS("Campaign"),
  SAVES("Save / Load"),
  SETTINGS("Settings")
}

@Composable
fun ArchiveScreen(
  uiState: GameUiState,
  onSaveToSlot: (Int) -> Unit,
  onLoadFromSlot: (Int) -> Unit,
  onDeleteSlot: (Int) -> Unit,
  onSelectChapter: (Int) -> Unit,
  onRestartTutorial: () -> Unit,
  onUpdateSettings: (GameSettings) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableStateOf(ArchiveTab.PRINTED_EDITIONS) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 12.dp)
  ) {
    // Header
    item {
      NewspaperMasthead(
        editionDate = uiState.currentChapter.historicalDate,
        editionType = "HISTORICAL MORGUE & ARCHIVES",
        clockTimeFormatted = uiState.clockFormatted,
        minutesRemaining = uiState.minutesRemaining
      )
    }

    // Tabs
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        ArchiveTab.values().forEach { tab ->
          val isSelected = tab == selectedTab
          Button(
            onClick = { selectedTab = tab },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
              contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            ),
            shape = MaterialTheme.shapes.extraSmall,
            modifier = Modifier
              .weight(1f)
              .defaultMinSize(minHeight = 44.dp)
              .border(1.dp, MaterialTheme.colorScheme.outline)
              .testTag("archive_tab_${tab.name.lowercase()}")
          ) {
            Text(
              text = tab.label.uppercase(),
              style = MaterialTheme.typography.labelSmall,
              fontFamily = CourierFontFamily,
              fontSize = 8.5.sp,
              textAlign = TextAlign.Center
            )
          }
        }
      }
      NewspaperSingleRule()
      Spacer(modifier = Modifier.height(8.dp))
    }

    when (selectedTab) {
      ArchiveTab.PRINTED_EDITIONS -> {
        item {
          VintageSectionTitle(
            title = "Printed Gazette Morgue",
            subtitle = "Record of all published newspaper runs from your tenure"
          )
          Spacer(modifier = Modifier.height(6.dp))
        }

        if (uiState.printedEditions.isEmpty()) {
          item {
            InkCard(modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "No editions printed yet tonight. Work your stories on the Front Page and roll the presses before 03:00 AM.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
              )
            }
          }
        } else {
          items(uiState.printedEditions) { edition ->
            InkCard(
              borderColor = MaterialTheme.colorScheme.primary,
              modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                StampBadge(text = "EDITION #${edition.editionNumber}", color = StampRed)
                Text(
                  text = edition.dateString,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.secondary
                )
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = edition.leadHeadline,
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = PlayfairFontFamily,
                fontWeight = FontWeight.Bold
              )

              Spacer(modifier = Modifier.height(4.dp))
              NewspaperSingleRule()
              Spacer(modifier = Modifier.height(4.dp))

              Text(
                text = edition.leadBody,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 4
              )

              Spacer(modifier = Modifier.height(8.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "Trust: ${edition.publicTrustScore}%",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = StampGreen
                )
                Text(
                  text = "Police Heat: ${edition.policePressureScore}%",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = StampRed
                )
                Text(
                  text = "Legal Exposure: ${edition.legalExposureScore}%",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.secondary
                )
              }

              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = edition.editorialSummary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      ArchiveTab.JOURNAL -> {
        item {
          VintageSectionTitle(
            title = "Chronological Night Shift Journal",
            subtitle = "Every dispatched lead, interview quote, and deduction recorded by timestamp"
          )
          Spacer(modifier = Modifier.height(6.dp))
        }

        items(uiState.journalEntries.reversed()) { entry ->
          InkCard(
            borderColor = if (entry.isImportant) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = entry.timestampLabel,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = CourierFontFamily,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = "CH. ${entry.chapterId}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
              )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = entry.text,
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = if (entry.isImportant) FontWeight.SemiBold else FontWeight.Normal,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      ArchiveTab.CHAPTERS -> {
        item {
          VintageSectionTitle(
            title = "Campaign Chapters (1947)",
            subtitle = "Eight interconnected mysteries of the Greybridge Iron Syndicate"
          )
          Spacer(modifier = Modifier.height(6.dp))
        }

        items(GameContentRepository.chapters) { chapter ->
          val isCurrent = chapter.id == uiState.currentChapter.id
          val isCompleted = uiState.completedChapterIds.contains(chapter.id)
          val isUnlocked = chapter.id <= uiState.currentChapter.id || isCompleted

          InkCard(
            borderColor = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
            backgroundColor = if (isCurrent) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              StampBadge(
                text = "CHAPTER ${chapter.id}",
                color = if (isCurrent) StampRed else if (isCompleted) StampGreen else InkMuted
              )
              Text(
                text = chapter.historicalDate,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = chapter.title,
              style = MaterialTheme.typography.titleMedium,
              fontFamily = PlayfairFontFamily,
              fontWeight = FontWeight.Bold
            )

            Text(
              text = chapter.subtitle,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.secondary
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = chapter.briefSummary,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (isUnlocked && !isCurrent) {
              VintageButton(
                text = "Select & Investigate Chapter ${chapter.id}",
                onClick = { onSelectChapter(chapter.id) },
                isPrimary = false,
                modifier = Modifier.fillMaxWidth()
              )
            } else if (isCurrent) {
              Text(
                text = "CURRENTLY ACTIVE CHAPTER",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }
      }

      ArchiveTab.SAVES -> {
        item {
          VintageSectionTitle(
            title = "Campaign Save & Load Manager",
            subtitle = "Local offline persistence with versioned slots"
          )
          Spacer(modifier = Modifier.height(6.dp))

          // Save current game button
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            VintageButton(
              text = "Save to Slot 1",
              onClick = { onSaveToSlot(1) },
              modifier = Modifier.weight(1f).testTag("save_slot_1_btn")
            )
            VintageButton(
              text = "Save to Slot 2",
              onClick = { onSaveToSlot(2) },
              modifier = Modifier.weight(1f).testTag("save_slot_2_btn")
            )
            VintageButton(
              text = "Save to Slot 3",
              onClick = { onSaveToSlot(3) },
              modifier = Modifier.weight(1f).testTag("save_slot_3_btn")
            )
          }

          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "SAVED CAMPAIGN SLOTS:",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
          )
          Spacer(modifier = Modifier.height(6.dp))
        }

        items(uiState.saveSlotList) { slot ->
          InkCard(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = if (slot.slotIndex == 0) "AUTO-SAVE SLOT" else "MANUAL SLOT #${slot.slotIndex}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              StampBadge(
                text = if (slot.isEmpty) "EMPTY" else "ACTIVE SAVE",
                color = if (slot.isEmpty) InkMuted else StampGreen
              )
            }

            if (!slot.isEmpty) {
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Chapter ${slot.chapterNumber}: ${slot.chapterTitle}",
                style = MaterialTheme.typography.titleSmall,
                fontFamily = PlayfairFontFamily,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Game Clock: ${slot.gameTimeFormatted} • Date: ${slot.dateFormatted}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                VintageButton(
                  text = "Load Slot",
                  onClick = { onLoadFromSlot(slot.slotIndex) },
                  modifier = Modifier.weight(1f).testTag("load_slot_${slot.slotIndex}")
                )
                if (slot.slotIndex != 0) {
                  VintageButton(
                    text = "Delete",
                    onClick = { onDeleteSlot(slot.slotIndex) },
                    isPrimary = false,
                    modifier = Modifier.weight(1f)
                  )
                }
              }
            } else {
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Empty slot. Use the buttons above to record current campaign state.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      ArchiveTab.SETTINGS -> {
        item {
          VintageSectionTitle(
            title = "Gazette Desk Settings",
            subtitle = "Accessibility, visual textures, and game replay"
          )
          Spacer(modifier = Modifier.height(8.dp))

          // Darkroom mode toggle
          InkCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Night Newsroom Noir Mode",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Dark lamplit aesthetic for night investigation.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Switch(
                checked = uiState.settings.isDarkroomMode,
                onCheckedChange = { onUpdateSettings(uiState.settings.copy(isDarkroomMode = it)) }
              )
            }
          }

          // Reduced texture mode toggle
          InkCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Reduced Texture Mode",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Flat crisp paper for maximum readability.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Switch(
                checked = uiState.settings.isReducedTexture,
                onCheckedChange = { onUpdateSettings(uiState.settings.copy(isReducedTexture = it)) }
              )
            }
          }

          // Replay Tutorial
          Spacer(modifier = Modifier.height(10.dp))
          VintageButton(
            text = "Replay Tutorial (The First Night Shift)",
            onClick = onRestartTutorial,
            isPrimary = false,
            modifier = Modifier.fillMaxWidth().testTag("replay_tutorial_btn"),
            leadIcon = { Icon(Icons.Filled.School, contentDescription = null) }
          )
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
