package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.EvidenceItem
import com.example.model.EvidenceStatus
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun EvidenceDetailDialog(
  item: EvidenceItem,
  onDismiss: () -> Unit,
  onUpdateStatus: (EvidenceStatus) -> Unit,
  onSaveNotes: (String) -> Unit
) {
  var notesText by remember { mutableStateOf(item.userNotes) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = MaterialTheme.shapes.extraSmall,
      color = MaterialTheme.colorScheme.surface,
      border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 16.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(16.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Top Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          StampBadge(text = item.category.displayName, color = MaterialTheme.colorScheme.secondary)
          IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_evidence_dialog")) {
            Icon(Icons.Filled.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = item.title,
          style = MaterialTheme.typography.headlineMedium,
          fontFamily = PlayfairFontFamily,
          fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Source: ${item.source} • Obtained: ${item.dateObtained}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.secondary
        )

        Spacer(modifier = Modifier.height(6.dp))
        NewspaperDoubleRule()
        Spacer(modifier = Modifier.height(6.dp))

        // Document Content (Typewriter box)
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(10.dp)
        ) {
          Text(
            text = item.detailedContent,
            style = MaterialTheme.typography.bodyMedium,
            fontFamily = CourierFontFamily,
            color = MaterialTheme.colorScheme.onSurface,
            lineHeight = 20.sp
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // People & Locations Involved
        if (item.peopleInvolved.isNotEmpty()) {
          Text(
            text = "PERSONS OF INTEREST: " + item.peopleInvolved.joinToString(", "),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
          )
        }
        if (item.locationsInvolved.isNotEmpty()) {
          Text(
            text = "LOCATIONS: " + item.locationsInvolved.joinToString(", "),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
          )
        }

        Spacer(modifier = Modifier.height(10.dp))
        NewspaperSingleRule()
        Spacer(modifier = Modifier.height(8.dp))

        // Mark Status Section
        Text(
          text = "EDITORIAL ASSESSMENT:",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          EvidenceStatus.values().forEach { st ->
            val isSelected = item.status == st
            Button(
              onClick = { onUpdateStatus(st) },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
              ),
              shape = MaterialTheme.shapes.extraSmall,
              modifier = Modifier
                .weight(1f)
                .border(1.dp, MaterialTheme.colorScheme.outline)
            ) {
              Text(
                text = st.label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.5.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Notes Input
        OutlinedTextField(
          value = notesText,
          onValueChange = {
            notesText = it
            onSaveNotes(it)
          },
          label = { Text("Reporter Case Notes", style = MaterialTheme.typography.labelSmall) },
          placeholder = { Text("Record inferences, cross-references, or leads...", style = MaterialTheme.typography.bodySmall) },
          modifier = Modifier.fillMaxWidth(),
          minLines = 2
        )

        Spacer(modifier = Modifier.height(12.dp))

        VintageButton(
          text = "Return to Case Files",
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth()
        )
      }
    }
  }
}
