package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun InkCard(
  modifier: Modifier = Modifier,
  borderColor: Color = MaterialTheme.colorScheme.outlineVariant,
  backgroundColor: Color = MaterialTheme.colorScheme.surface,
  onClick: (() -> Unit)? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  val baseModifier = modifier
    .border(1.dp, borderColor, RoundedCornerShape(2.dp))
    .background(backgroundColor, RoundedCornerShape(2.dp))
    .padding(12.dp)

  val finalModifier = if (onClick != null) {
    baseModifier.clickable { onClick() }
  } else {
    baseModifier
  }

  Column(modifier = finalModifier) {
    content()
  }
}

@Composable
fun StampBadge(
  text: String,
  color: Color = StampRed,
  rotationDegrees: Float = -2.5f,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .rotate(rotationDegrees)
      .border(1.5.dp, color.copy(alpha = 0.85f), RoundedCornerShape(2.dp))
      .background(color.copy(alpha = 0.08f))
      .padding(horizontal = 7.dp, vertical = 2.dp)
  ) {
    Text(
      text = text.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      fontFamily = CourierFontFamily,
      fontWeight = FontWeight.Bold,
      color = color,
      letterSpacing = 1.sp
    )
  }
}

@Composable
fun NewsroomMeterBar(
  publicTrust: Int,
  policeHeat: Int,
  legalExposure: Int,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
      .background(MaterialTheme.colorScheme.surfaceVariant)
      .padding(horizontal = 10.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    NewsroomMeterItem(
      label = "READER TRUST",
      value = "$publicTrust%",
      color = if (publicTrust >= 60) StampGreen else StampRed
    )
    VerticalDivider(
      modifier = Modifier
        .height(18.dp)
        .width(1.dp),
      color = MaterialTheme.colorScheme.outlineVariant
    )
    NewsroomMeterItem(
      label = "POLICE HEAT",
      value = "$policeHeat%",
      color = if (policeHeat >= 50) StampRed else InkMuted
    )
    VerticalDivider(
      modifier = Modifier
        .height(18.dp)
        .width(1.dp),
      color = MaterialTheme.colorScheme.outlineVariant
    )
    NewsroomMeterItem(
      label = "LEGAL RISK",
      value = "$legalExposure%",
      color = if (legalExposure >= 50) StampRed else InkMuted
    )
  }
}

@Composable
private fun NewsroomMeterItem(
  label: String,
  value: String,
  color: Color
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      fontSize = 9.sp
    )
    Text(
      text = value,
      style = MaterialTheme.typography.labelMedium,
      fontWeight = FontWeight.Bold,
      color = color
    )
  }
}

@Composable
fun VintageSectionTitle(
  title: String,
  subtitle: String? = null,
  modifier: Modifier = Modifier
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .weight(1f)
          .height(1.dp)
          .background(MaterialTheme.colorScheme.outline)
      )
      Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.titleMedium,
        fontFamily = PlayfairFontFamily,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.padding(horizontal = 8.dp)
      )
      Box(
        modifier = Modifier
          .weight(1f)
          .height(1.dp)
          .background(MaterialTheme.colorScheme.outline)
      )
    }
    if (subtitle != null) {
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
      )
    }
  }
}

@Composable
fun VintageButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  isPrimary: Boolean = true,
  leadIcon: @Composable (() -> Unit)? = null
) {
  val bgColor = if (isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
  val contentColor = if (isPrimary) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
  val borderModifier = if (!isPrimary) Modifier.border(1.dp, MaterialTheme.colorScheme.outline) else Modifier

  Button(
    onClick = onClick,
    enabled = enabled,
    modifier = modifier
      .defaultMinSize(minHeight = 48.dp)
      .then(borderModifier),
    shape = RoundedCornerShape(2.dp),
    colors = ButtonDefaults.buttonColors(
      containerColor = bgColor,
      contentColor = contentColor,
      disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
      disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
    ),
    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      if (leadIcon != null) {
        leadIcon()
        Spacer(modifier = Modifier.width(6.dp))
      }
      Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        fontFamily = CourierFontFamily,
        fontWeight = FontWeight.Bold
      )
    }
  }
}
