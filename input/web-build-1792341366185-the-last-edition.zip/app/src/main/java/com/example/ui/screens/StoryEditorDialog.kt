package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.EditorialStance
import com.example.model.NewspaperStory
import com.example.model.StorySlot
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun StoryEditorDialog(
  story: NewspaperStory,
  onDismiss: () -> Unit,
  onSaveDecision: (EditorialStance, StorySlot?) -> Unit
) {
  var selectedStance by remember { mutableStateOf(story.selectedStance) }
  var selectedSlot by remember { mutableStateOf(story.assignedSlot) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = MaterialTheme.shapes.extraSmall,
      color = MaterialTheme.colorScheme.surface,
      border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 16.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(16.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          StampBadge(text = "EDITORIAL DESK", color = StampRed)
          IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_story_editor")) {
            Icon(Icons.Filled.Close, contentDescription = "Close")
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = story.headline,
          style = MaterialTheme.typography.headlineMedium,
          fontFamily = PlayfairFontFamily,
          fontWeight = FontWeight.Bold
        )

        Text(
          text = story.subHeadline,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(6.dp))
        NewspaperDoubleRule()
        Spacer(modifier = Modifier.height(6.dp))

        // Metadata specs
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "Verification: ${story.verificationLevel}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
          )
          Text(
            text = "Risk: ${story.legalRisk}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = StampRed
          )
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Political Impact: ${story.politicalImpact}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(10.dp))

        // ASSIGN FRONT PAGE SLOT
        Text(
          text = "ASSIGN FRONT PAGE SLOT:",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          StorySlot.values().forEach { slot ->
            val isSelected = selectedSlot == slot
            Button(
              onClick = { selectedSlot = slot },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
              ),
              shape = MaterialTheme.shapes.extraSmall,
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline)
                .testTag("slot_btn_${slot.name.lowercase()}")
            ) {
              Text(
                text = slot.label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
              )
            }
          }
          // Unassign option
          Button(
            onClick = { selectedSlot = null },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (selectedSlot == null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surface,
              contentColor = if (selectedSlot == null) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onSurface
            ),
            shape = MaterialTheme.shapes.extraSmall,
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, MaterialTheme.colorScheme.outline)
          ) {
            Text(
              text = "HOLD IN RESERVE (UNASSIGNED)",
              style = MaterialTheme.typography.labelSmall
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))
        NewspaperSingleRule()
        Spacer(modifier = Modifier.height(8.dp))

        // EDITORIAL STANCE
        Text(
          text = "CHOOSE EDITORIAL STANCE:",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))

        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          EditorialStance.values().forEach { stance ->
            val isSelected = selectedStance == stance
            Button(
              onClick = { selectedStance = stance },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
              ),
              shape = MaterialTheme.shapes.extraSmall,
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline)
                .testTag("stance_btn_${stance.name.lowercase()}")
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = stance.label.uppercase(),
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = stance.description,
                  style = MaterialTheme.typography.bodySmall,
                  fontSize = 10.sp,
                  color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        VintageButton(
          text = "Commit Editorial Stance",
          onClick = { onSaveDecision(selectedStance, selectedSlot) },
          modifier = Modifier.fillMaxWidth().testTag("commit_stance_btn")
        )
      }
    }
  }
}
