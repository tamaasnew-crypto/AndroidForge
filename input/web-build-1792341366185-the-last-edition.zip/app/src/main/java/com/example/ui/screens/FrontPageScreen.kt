package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.GameUiState

@Composable
fun FrontPageScreen(
  uiState: GameUiState,
  onOpenStoryEditor: (NewspaperStory) -> Unit,
  onPrintPresses: () -> Unit,
  modifier: Modifier = Modifier
) {
  val leadStory = uiState.availableStories.find { it.assignedSlot == StorySlot.LEAD_BANNER }
  val columnStory = uiState.availableStories.find { it.assignedSlot == StorySlot.SECONDARY_COLUMN }
  val wireStory = uiState.availableStories.find { it.assignedSlot == StorySlot.WIRE_SIDEBAR }

  var showConfirmPrintDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 12.dp)
  ) {
    // Masthead
    item {
      NewspaperMasthead(
        editionDate = uiState.currentChapter.historicalDate,
        clockTimeFormatted = uiState.clockFormatted,
        minutesRemaining = uiState.minutesRemaining
      )
    }

    // Meter Bar
    item {
      NewsroomMeterBar(
        publicTrust = uiState.publicTrust,
        policeHeat = uiState.policeHeat,
        legalExposure = uiState.legalRisk,
        modifier = Modifier.padding(vertical = 4.dp)
      )
    }

    // Hero banner image of Greybridge 1947
    item {
      Spacer(modifier = Modifier.height(6.dp))
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(130.dp)
          .border(1.dp, MaterialTheme.colorScheme.outline)
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_greybridge_hero),
          contentDescription = "Greybridge 1947 City Skyline and Newsroom",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )
        // Caption tag
        Box(
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .background(Color.Black.copy(alpha = 0.75f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "GREYBRIDGE DOCKS AT MIDNIGHT • RAIN OVER BERTH 3",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            fontSize = 8.5.sp
          )
        }
      }
      Spacer(modifier = Modifier.height(8.dp))
    }

    // Deadline warning if low on time
    if (uiState.minutesRemaining <= 60) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = StampRed.copy(alpha = 0.1f)),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, StampRed)
            .padding(bottom = 8.dp)
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Filled.Warning, contentDescription = null, tint = StampRed)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "DEADLINE WARNING: ${uiState.minutesRemaining} MINUTES REMAINING",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = StampRed
              )
              Text(
                text = "Rotary cylinders will be locked at 03:00 AM. Ensure your lead banner story is verified.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }

    // LEAD BANNER STORY SECTION
    item {
      VintageSectionTitle(
        title = "Lead Headline Story",
        subtitle = "Main front page banner running across all 6 columns"
      )
      Spacer(modifier = Modifier.height(4.dp))

      if (leadStory != null) {
        InkCard(
          borderColor = MaterialTheme.colorScheme.primary,
          backgroundColor = MaterialTheme.colorScheme.surface,
          onClick = { onOpenStoryEditor(leadStory) },
          modifier = Modifier.fillMaxWidth().testTag("lead_banner_card")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            StampBadge(text = leadStory.selectedStance.label, color = StampRed)
            Text(
              text = leadStory.verificationLevel,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.secondary
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = leadStory.headline,
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            fontFamily = PlayfairFontFamily,
            color = MaterialTheme.colorScheme.onBackground
          )

          Spacer(modifier = Modifier.height(2.dp))

          Text(
            text = leadStory.subHeadline,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(4.dp))
          NewspaperSingleRule()
          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = if (leadStory.selectedStance == EditorialStance.PUBLISH_FULL) leadStory.fullArticleText else leadStory.cautiousArticleText,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 4,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = leadStory.authorByline.uppercase(),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = "TAP TO CHANGE STANCE",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      } else {
        InkCard(
          borderColor = MaterialTheme.colorScheme.outlineVariant,
          backgroundColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "[ NO LEAD STORY ASSIGNED ]",
            style = MaterialTheme.typography.titleMedium,
            fontFamily = CourierFontFamily,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
          )
          Text(
            text = "Select an investigative story below and assign it to the Lead Banner slot.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))
    }

    // SECONDARY & WIRE SLOTS
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Secondary Column
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "COLUMN TWO",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
          )
          NewspaperSingleRule(modifier = Modifier.padding(vertical = 3.dp))
          if (columnStory != null) {
            InkCard(
              onClick = { onOpenStoryEditor(columnStory) },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = columnStory.headline,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                fontFamily = PlayfairFontFamily,
                maxLines = 2
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = columnStory.selectedStance.label,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.5.sp,
                color = MaterialTheme.colorScheme.secondary
              )
            }
          } else {
            InkCard(modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "Unassigned",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }

        // Wire Sidebar
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "CITY WIRE",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
          )
          NewspaperSingleRule(modifier = Modifier.padding(vertical = 3.dp))
          if (wireStory != null) {
            InkCard(
              onClick = { onOpenStoryEditor(wireStory) },
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = wireStory.headline,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                fontFamily = PlayfairFontFamily,
                maxLines = 2
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = wireStory.selectedStance.label,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.5.sp,
                color = MaterialTheme.colorScheme.secondary
              )
            }
          } else {
            InkCard(modifier = Modifier.fillMaxWidth()) {
              Text(
                text = "Unassigned",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }

    // STORY DESK REPOSITORY (Available stories to assign)
    item {
      VintageSectionTitle(
        title = "Story Desk & Editorial Assignments",
        subtitle = "Available investigative pieces for tonight's run"
      )
      Spacer(modifier = Modifier.height(6.dp))
    }

    items(uiState.availableStories) { story ->
      InkCard(
        borderColor = if (story.assignedSlot != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        onClick = { onOpenStoryEditor(story) },
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = story.assignedSlot?.label ?: "UNASSIGNED",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = CourierFontFamily,
            fontWeight = FontWeight.Bold,
            color = if (story.assignedSlot != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
          )
          StampBadge(
            text = story.selectedStance.label,
            color = if (story.selectedStance == EditorialStance.KILL_STORY) StampRed else StampGreen
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = story.headline,
          style = MaterialTheme.typography.titleMedium,
          fontFamily = PlayfairFontFamily,
          fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(2.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = "Verification: ${story.verificationLevel}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.secondary
          )
          Text(
            text = "Legal: ${story.legalRisk}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // PRINT PRESS ACTION BUTTON
    item {
      Spacer(modifier = Modifier.height(16.dp))
      NewspaperDoubleRule()
      Spacer(modifier = Modifier.height(12.dp))

      VintageButton(
        text = "Lock Plates & Roll Presses (Print Edition)",
        onClick = { showConfirmPrintDialog = true },
        isPrimary = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("roll_presses_button"),
        leadIcon = {
          Icon(Icons.Filled.Print, contentDescription = null, modifier = Modifier.size(20.dp))
        }
      )

      Spacer(modifier = Modifier.height(24.dp))
    }
  }

  // Print confirmation modal
  if (showConfirmPrintDialog) {
    AlertDialog(
      onDismissRequest = { showConfirmPrintDialog = false },
      title = {
        Text(
          text = "CONFIRM PRINT RUN",
          fontFamily = PlayfairFontFamily,
          fontWeight = FontWeight.Bold
        )
      },
      text = {
        Column {
          Text(
            text = "Are you ready to lock the linotype plates and commence printing 40,000 copies of tonight's edition?",
            style = MaterialTheme.typography.bodyMedium
          )
          val bannerTitle = leadStory?.headline ?: "MIDNIGHT SILENCE OVER GREYBRIDGE"
          Text(
            text = "Lead Banner: $bannerTitle",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "Your editorial choices will permanently alter source trust, police reaction, and the course of the city investigation.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      },
      confirmButton = {
        TextButton(
          onClick = {
            showConfirmPrintDialog = false
            onPrintPresses()
          },
          modifier = Modifier.testTag("confirm_print_btn")
        ) {
          Text("START ROTARY PRESS", fontWeight = FontWeight.Bold, color = StampRed)
        }
      },
      dismissButton = {
        TextButton(onClick = { showConfirmPrintDialog = false }) {
          Text("RETURN TO DESK")
        }
      }
    )
  }
}
