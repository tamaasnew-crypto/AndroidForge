package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.InvestigationLead
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.GameUiState

data class CityDistrict(
  val name: String,
  val category: String,
  val icon: ImageVector,
  val description: String,
  val dangerLevel: String
)

@Composable
fun CityDeskScreen(
  uiState: GameUiState,
  onInvestigateLead: (InvestigationLead) -> Unit,
  onOpenSourceInterview: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val districts = listOf(
    CityDistrict(
      name = "Gazette Building",
      category = "Newsroom & Press Pit",
      icon = Icons.Filled.Business,
      description = "Where the Goss rotary presses run in the basement and Linotype operators set hot lead.",
      dangerLevel = "Controlled"
    ),
    CityDistrict(
      name = "Vulcan Slagworks",
      category = "Heavy Industrial Basin",
      icon = Icons.Filled.PrecisionManufacturing,
      description = "Blast furnaces glow red in the smog. Guarded by armed company watchmen.",
      dangerLevel = "Hostile"
    ),
    CityDistrict(
      name = "Black Dog Tavern",
      category = "Canal Wharf",
      icon = Icons.Filled.LocalBar,
      description = "Dingy sailors' watering hole where Arthur Pendelton is lying low.",
      dangerLevel = "Watchful"
    ),
    CityDistrict(
      name = "4th Precinct Station",
      category = "Municipal Police HQ",
      icon = Icons.Filled.Shield,
      description = "Inspector Reed's station. Radio silence ordered for the harbor zone.",
      dangerLevel = "High Surveillance"
    ),
    CityDistrict(
      name = "St. Jude's District",
      category = "Tenements & Parish",
      icon = Icons.Filled.Church,
      description = "Silent streets of ironworkers. Father O'Malley keeps the true records.",
      dangerLevel = "Tense"
    ),
    CityDistrict(
      name = "Wharf Warehouse 7",
      category = "Cargo Berth 3",
      icon = Icons.Filled.Anchor,
      description = "Where the contraband titanium ore shipments are transferred onto steamers.",
      dangerLevel = "Dangerous"
    )
  )

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 12.dp)
  ) {
    // Header
    item {
      NewspaperMasthead(
        editionDate = uiState.currentChapter.historicalDate,
        editionType = "CITY DESK INVESTIGATION HUB",
        clockTimeFormatted = uiState.clockFormatted,
        minutesRemaining = uiState.minutesRemaining
      )
    }

    // CHAPTER NARRATIVE BRIEFING
    item {
      InkCard(
        borderColor = MaterialTheme.colorScheme.primary,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          StampBadge(text = "CHAPTER ${uiState.currentChapter.id}", color = StampRed)
          Text(
            text = uiState.currentChapter.subtitle.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.secondary
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = uiState.currentChapter.title,
          style = MaterialTheme.typography.headlineMedium,
          fontFamily = PlayfairFontFamily,
          fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))
        NewspaperSingleRule()
        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = uiState.currentChapter.narrativeIntro,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "CORE OBJECTIVE: ${uiState.currentChapter.briefSummary}",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
      }

      Spacer(modifier = Modifier.height(10.dp))
    }

    // ACTIVE INVESTIGATION LEADS
    item {
      VintageSectionTitle(
        title = "Active Investigative Leads",
        subtitle = "Dispatch reporters or inspect crime scenes before print deadline"
      )
      Spacer(modifier = Modifier.height(6.dp))
    }

    if (uiState.activeLeads.isEmpty()) {
      item {
        InkCard(modifier = Modifier.fillMaxWidth()) {
          Text(
            text = "No active leads available. Compare evidence in Case Files to deduce new leads.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
          )
        }
      }
    } else {
      items(uiState.activeLeads) { lead ->
        InkCard(
          borderColor = if (lead.isCompleted) MaterialTheme.colorScheme.outlineVariant else MaterialTheme.colorScheme.secondary,
          backgroundColor = if (lead.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface,
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("lead_item_${lead.id}")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Filled.LocationOn,
                contentDescription = null,
                tint = if (lead.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else StampRed,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = lead.location.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
              )
            }
            Text(
              text = "Cost: ${lead.timeCostMinutes} mins",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = lead.title,
            style = MaterialTheme.typography.titleMedium,
            fontFamily = PlayfairFontFamily,
            fontWeight = FontWeight.Bold
          )

          Spacer(modifier = Modifier.height(2.dp))

          Text(
            text = lead.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(8.dp))

          if (lead.isCompleted) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = StampGreen, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "INVESTIGATION COMPLETED • EVIDENCE CATALOGUED",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = StampGreen
              )
            }
          } else {
            VintageButton(
              text = "Investigate Location (${lead.timeCostMinutes}m)",
              onClick = { onInvestigateLead(lead) },
              modifier = Modifier.fillMaxWidth().testTag("investigate_lead_btn_${lead.id}")
            )
          }
        }
      }
    }

    // CITY DIRECTORY & LOCAL MAP
    item {
      Spacer(modifier = Modifier.height(14.dp))
      VintageSectionTitle(
        title = "Greybridge Municipal Territory",
        subtitle = "Key industrial centers and suspect sectors"
      )
      Spacer(modifier = Modifier.height(6.dp))
    }

    items(districts) { district ->
      InkCard(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 3.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            district.icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = district.name,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                fontFamily = PlayfairFontFamily
              )
              Text(
                text = district.dangerLevel.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.5.sp,
                color = if (district.dangerLevel == "Controlled") StampGreen else StampRed
              )
            }
            Text(
              text = district.category,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.secondary
            )
            Text(
              text = district.description,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
