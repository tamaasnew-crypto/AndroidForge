package com.example.data

import android.content.Context
import com.example.model.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class SaveManager(private val context: Context) {

  private val saveDir = File(context.filesDir, "saves").apply {
    if (!exists()) mkdirs()
  }

  fun getSaveFile(slotIndex: Int): File {
    return File(saveDir, if (slotIndex == 0) "autosave.json" else "slot_$slotIndex.json")
  }

  fun saveGame(slotIndex: Int, data: GameSaveData): Boolean {
    return try {
      val json = serialize(data.copy(lastSavedTimestamp = System.currentTimeMillis()))
      val file = getSaveFile(slotIndex)
      file.writeText(json)
      true
    } catch (e: Exception) {
      e.printStackTrace()
      false
    }
  }

  fun loadGame(slotIndex: Int): GameSaveData? {
    return try {
      val file = getSaveFile(slotIndex)
      if (!file.exists()) return null
      val json = file.readText()
      deserialize(json)
    } catch (e: Exception) {
      e.printStackTrace()
      null
    }
  }

  fun listSaveSlots(): List<SaveSlotSummary> {
    return (0..3).map { slot ->
      val file = getSaveFile(slot)
      if (file.exists()) {
        try {
          val data = deserialize(file.readText())
          val chapter = GameContentRepository.chapters.find { it.id == data.currentChapterId }
          val hour = 23 + (data.elapsedNightMinutes / 60)
          val minute = data.elapsedNightMinutes % 60
          val timeLabel = String.format("%02d:%02d %s", if (hour > 24) hour - 24 else if (hour == 24) 12 else hour - 12, minute, if (hour >= 24) "AM" else "PM")
          SaveSlotSummary(
            slotIndex = slot,
            isEmpty = false,
            chapterTitle = chapter?.title ?: "Chapter ${data.currentChapterId}",
            chapterNumber = data.currentChapterId,
            dateFormatted = chapter?.historicalDate ?: "October 1947",
            gameTimeFormatted = timeLabel
          )
        } catch (e: Exception) {
          SaveSlotSummary(slotIndex = slot, isEmpty = true)
        }
      } else {
        SaveSlotSummary(slotIndex = slot, isEmpty = true)
      }
    }
  }

  fun deleteSlot(slotIndex: Int): Boolean {
    val file = getSaveFile(slotIndex)
    return if (file.exists()) file.delete() else true
  }

  private fun serialize(data: GameSaveData): String {
    val root = JSONObject()
    root.put("saveVersion", data.saveVersion)
    root.put("currentChapterId", data.currentChapterId)
    root.put("elapsedNightMinutes", data.elapsedNightMinutes)
    root.put("publicTrustScore", data.publicTrustScore)
    root.put("policeHeatScore", data.policeHeatScore)
    root.put("legalRiskScore", data.legalRiskScore)
    root.put("lastSavedTimestamp", data.lastSavedTimestamp)
    root.put("isTutorialActive", data.isTutorialActive)
    root.put("tutorialStep", data.tutorialStep)
    root.put("tutorialCompleted", data.tutorialCompleted)

    val evArray = JSONArray()
    data.unlockedEvidenceIds.forEach { evArray.put(it) }
    root.put("unlockedEvidenceIds", evArray)

    val evStatusObj = JSONObject()
    data.evidenceStatuses.forEach { (k, v) -> evStatusObj.put(k, v) }
    root.put("evidenceStatuses", evStatusObj)

    val evNotesObj = JSONObject()
    data.evidenceNotes.forEach { (k, v) -> evNotesObj.put(k, v) }
    root.put("evidenceNotes", evNotesObj)

    val leadArray = JSONArray()
    data.unlockedLeadIds.forEach { leadArray.put(it) }
    root.put("unlockedLeadIds", leadArray)

    val compLeadArray = JSONArray()
    data.completedLeadIds.forEach { compLeadArray.put(it) }
    root.put("completedLeadIds", compLeadArray)

    val trustObj = JSONObject()
    data.sourceTrustScores.forEach { (k, v) -> trustObj.put(k, v) }
    root.put("sourceTrustScores", trustObj)

    val storyDecObj = JSONObject()
    data.storyDecisions.forEach { (k, v) -> storyDecObj.put(k, v) }
    root.put("storyDecisions", storyDecObj)

    val slotAssObj = JSONObject()
    data.storySlotAssignments.forEach { (k, v) -> slotAssObj.put(k, v) }
    root.put("storySlotAssignments", slotAssObj)

    val dedArray = JSONArray()
    data.completedDeductionIds.forEach { dedArray.put(it) }
    root.put("completedDeductionIds", dedArray)

    val journalArray = JSONArray()
    data.journalEntries.forEach { j ->
      val jObj = JSONObject()
      jObj.put("id", j.id)
      jObj.put("timestampLabel", j.timestampLabel)
      jObj.put("text", j.text)
      jObj.put("chapterId", j.chapterId)
      jObj.put("isImportant", j.isImportant)
      journalArray.put(jObj)
    }
    root.put("journalEntries", journalArray)

    val printedArray = JSONArray()
    data.printedEditions.forEach { p ->
      val pObj = JSONObject()
      pObj.put("editionNumber", p.editionNumber)
      pObj.put("dateString", p.dateString)
      pObj.put("editionTitle", p.editionTitle)
      pObj.put("leadHeadline", p.leadHeadline)
      pObj.put("leadBody", p.leadBody)
      pObj.put("columnHeadline", p.columnHeadline)
      pObj.put("columnBody", p.columnBody)
      pObj.put("sidebarHeadline", p.sidebarHeadline)
      pObj.put("sidebarBody", p.sidebarBody)
      pObj.put("publicTrustScore", p.publicTrustScore)
      pObj.put("policePressureScore", p.policePressureScore)
      pObj.put("legalExposureScore", p.legalExposureScore)
      pObj.put("editorialSummary", p.editorialSummary)
      printedArray.put(pObj)
    }
    root.put("printedEditions", printedArray)

    val compChaptersArray = JSONArray()
    data.completedChapterIds.forEach { compChaptersArray.put(it) }
    root.put("completedChapterIds", compChaptersArray)

    return root.toString()
  }

  private fun deserialize(jsonStr: String): GameSaveData {
    val root = JSONObject(jsonStr)
    val saveVersion = root.optInt("saveVersion", 1)
    val currentChapterId = root.optInt("currentChapterId", 1)
    val elapsedNightMinutes = root.optInt("elapsedNightMinutes", 0)
    val publicTrustScore = root.optInt("publicTrustScore", 65)
    val policeHeatScore = root.optInt("policeHeatScore", 20)
    val legalRiskScore = root.optInt("legalRiskScore", 15)
    val lastSavedTimestamp = root.optLong("lastSavedTimestamp", System.currentTimeMillis())
    val isTutorialActive = root.optBoolean("isTutorialActive", false)
    val tutorialStep = root.optInt("tutorialStep", 1)
    val tutorialCompleted = root.optBoolean("tutorialCompleted", false)

    val unlockedEvidence = mutableListOf<String>()
    root.optJSONArray("unlockedEvidenceIds")?.let { arr ->
      for (i in 0 until arr.length()) unlockedEvidence.add(arr.getString(i))
    }

    val evidenceStatuses = mutableMapOf<String, String>()
    root.optJSONObject("evidenceStatuses")?.let { obj ->
      val keys = obj.keys()
      while (keys.hasNext()) {
        val k = keys.next()
        evidenceStatuses[k] = obj.getString(k)
      }
    }

    val evidenceNotes = mutableMapOf<String, String>()
    root.optJSONObject("evidenceNotes")?.let { obj ->
      val keys = obj.keys()
      while (keys.hasNext()) {
        val k = keys.next()
        evidenceNotes[k] = obj.getString(k)
      }
    }

    val unlockedLeads = mutableListOf<String>()
    root.optJSONArray("unlockedLeadIds")?.let { arr ->
      for (i in 0 until arr.length()) unlockedLeads.add(arr.getString(i))
    }

    val completedLeads = mutableListOf<String>()
    root.optJSONArray("completedLeadIds")?.let { arr ->
      for (i in 0 until arr.length()) completedLeads.add(arr.getString(i))
    }

    val sourceTrustScores = mutableMapOf<String, Int>()
    root.optJSONObject("sourceTrustScores")?.let { obj ->
      val keys = obj.keys()
      while (keys.hasNext()) {
        val k = keys.next()
        sourceTrustScores[k] = obj.getInt(k)
      }
    }

    val storyDecisions = mutableMapOf<String, String>()
    root.optJSONObject("storyDecisions")?.let { obj ->
      val keys = obj.keys()
      while (keys.hasNext()) {
        val k = keys.next()
        storyDecisions[k] = obj.getString(k)
      }
    }

    val storySlotAssignments = mutableMapOf<String, String>()
    root.optJSONObject("storySlotAssignments")?.let { obj ->
      val keys = obj.keys()
      while (keys.hasNext()) {
        val k = keys.next()
        storySlotAssignments[k] = obj.getString(k)
      }
    }

    val completedDeductions = mutableListOf<String>()
    root.optJSONArray("completedDeductionIds")?.let { arr ->
      for (i in 0 until arr.length()) completedDeductions.add(arr.getString(i))
    }

    val journalEntries = mutableListOf<JournalEntry>()
    root.optJSONArray("journalEntries")?.let { arr ->
      for (i in 0 until arr.length()) {
        val jObj = arr.getJSONObject(i)
        journalEntries.add(
          JournalEntry(
            id = jObj.getString("id"),
            timestampLabel = jObj.getString("timestampLabel"),
            text = jObj.getString("text"),
            chapterId = jObj.getInt("chapterId"),
            isImportant = jObj.optBoolean("isImportant", false)
          )
        )
      }
    }

    val printedEditions = mutableListOf<PrintedEdition>()
    root.optJSONArray("printedEditions")?.let { arr ->
      for (i in 0 until arr.length()) {
        val pObj = arr.getJSONObject(i)
        printedEditions.add(
          PrintedEdition(
            editionNumber = pObj.getInt("editionNumber"),
            dateString = pObj.getString("dateString"),
            editionTitle = pObj.getString("editionTitle"),
            leadHeadline = pObj.getString("leadHeadline"),
            leadBody = pObj.getString("leadBody"),
            columnHeadline = pObj.getString("columnHeadline"),
            columnBody = pObj.getString("columnBody"),
            sidebarHeadline = pObj.getString("sidebarHeadline"),
            sidebarBody = pObj.getString("sidebarBody"),
            publicTrustScore = pObj.getInt("publicTrustScore"),
            policePressureScore = pObj.getInt("policePressureScore"),
            legalExposureScore = pObj.getInt("legalExposureScore"),
            editorialSummary = pObj.getString("editorialSummary")
          )
        )
      }
    }

    val completedChapters = mutableListOf<Int>()
    root.optJSONArray("completedChapterIds")?.let { arr ->
      for (i in 0 until arr.length()) completedChapters.add(arr.getInt(i))
    }

    return GameSaveData(
      saveVersion = saveVersion,
      currentChapterId = currentChapterId,
      elapsedNightMinutes = elapsedNightMinutes,
      publicTrustScore = publicTrustScore,
      policeHeatScore = policeHeatScore,
      legalRiskScore = legalRiskScore,
      unlockedEvidenceIds = unlockedEvidence,
      evidenceStatuses = evidenceStatuses,
      evidenceNotes = evidenceNotes,
      unlockedLeadIds = unlockedLeads,
      completedLeadIds = completedLeads,
      sourceTrustScores = sourceTrustScores,
      storyDecisions = storyDecisions,
      storySlotAssignments = storySlotAssignments,
      completedDeductionIds = completedDeductions,
      journalEntries = journalEntries,
      printedEditions = printedEditions,
      completedChapterIds = completedChapters,
      isTutorialActive = isTutorialActive,
      tutorialStep = tutorialStep,
      tutorialCompleted = tutorialCompleted,
      lastSavedTimestamp = lastSavedTimestamp
    )
  }
}
