package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.NavDestination
import com.example.ui.components.NewspaperBottomIndexBar
import com.example.ui.screens.*
import com.example.ui.theme.CourierFontFamily
import com.example.ui.theme.StampRed
import com.example.ui.theme.TheLastEditionTheme
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: GameViewModel = viewModel()
      val uiState by viewModel.uiState.collectAsStateWithLifecycle()

      TheLastEditionTheme(isDarkTheme = uiState.settings.isDarkroomMode) {
        // Back press handling
        BackHandler {
          when {
            uiState.selectedEvidence != null -> viewModel.closeEvidenceDetail()
            uiState.storyToEdit != null -> viewModel.closeStoryEditor()
            uiState.activeInterviewSource != null -> viewModel.endInterview()
            uiState.chapterResolution != null -> viewModel.dismissResolution()
            uiState.currentDestination != NavDestination.FRONT_PAGE -> viewModel.navigateTo(NavDestination.FRONT_PAGE)
            else -> finish()
          }
        }

        Scaffold(
          modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding(),
          bottomBar = {
            NewspaperBottomIndexBar(
              currentDestination = uiState.currentDestination,
              onNavigate = { viewModel.navigateTo(it) },
              unreadEvidenceCount = 0
            )
          }
        ) { innerPadding ->
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding)
          ) {
            // Main Screen by Destination
            when (uiState.currentDestination) {
              NavDestination.FRONT_PAGE -> FrontPageScreen(
                uiState = uiState,
                onOpenStoryEditor = { viewModel.openStoryEditor(it) },
                onPrintPresses = { viewModel.printNewspaperEdition() }
              )
              NavDestination.CITY_DESK -> CityDeskScreen(
                uiState = uiState,
                onInvestigateLead = { viewModel.investigateLead(it) },
                onOpenSourceInterview = { sourceId ->
                  val src = uiState.activeSources.find { it.id == sourceId }
                  if (src != null) {
                    viewModel.navigateTo(NavDestination.SOURCES)
                    viewModel.startInterview(src)
                  }
                }
              )
              NavDestination.CASE_FILES -> CaseFilesScreen(
                uiState = uiState,
                onOpenEvidenceDetail = { viewModel.openEvidenceDetail(it) },
                onSetCompareA = { viewModel.setCompareItemA(it) },
                onSetCompareB = { viewModel.setCompareItemB(it) },
                onExecuteDeduction = { viewModel.executeCompareAndDeduce() },
                onDismissDeductionResult = { viewModel.dismissDeductionResult() }
              )
              NavDestination.SOURCES -> SourcesScreen(
                uiState = uiState,
                onStartInterview = { viewModel.startInterview(it) },
                onSelectDialogueOption = { viewModel.selectDialogueOption(it) },
                onEndInterview = { viewModel.endInterview() }
              )
              NavDestination.ARCHIVE -> ArchiveScreen(
                uiState = uiState,
                onSaveToSlot = { viewModel.saveGameToSlot(it) },
                onLoadFromSlot = { viewModel.loadGameFromSlot(it) },
                onDeleteSlot = { viewModel.deleteSaveSlot(it) },
                onSelectChapter = { viewModel.startNewCampaign(it) },
                onRestartTutorial = { viewModel.restartTutorial() },
                onUpdateSettings = { viewModel.updateSettings(it) }
              )
            }

            // Top Tutorial Banner
            if (uiState.isTutorialActive) {
              TutorialBanner(
                step = uiState.tutorialStep,
                onDismissTutorial = { viewModel.dismissTutorial() },
                modifier = Modifier
                  .align(Alignment.TopCenter)
                  .padding(8.dp)
              )
            }

            // Notification Banner Popup
            AnimatedVisibility(
              visible = uiState.bannerNotification != null,
              enter = fadeIn() + slideInVertically(),
              exit = fadeOut() + slideOutVertically(),
              modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp, start = 12.dp, end = 12.dp)
            ) {
              uiState.bannerNotification?.let { msg ->
                Surface(
                  shape = MaterialTheme.shapes.extraSmall,
                  color = MaterialTheme.colorScheme.primary,
                  border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.dismissNotification() }
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = msg,
                      style = MaterialTheme.typography.labelSmall,
                      fontFamily = CourierFontFamily,
                      color = MaterialTheme.colorScheme.onPrimary,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.weight(1f)
                    )
                    Text(
                      text = "DISMISS",
                      style = MaterialTheme.typography.labelSmall,
                      color = StampRed,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(start = 8.dp)
                    )
                  }
                }
              }
            }

            // Evidence Detail Modal Dialog
            uiState.selectedEvidence?.let { item ->
              EvidenceDetailDialog(
                item = item,
                onDismiss = { viewModel.closeEvidenceDetail() },
                onUpdateStatus = { viewModel.updateEvidenceStatus(item.id, it) },
                onSaveNotes = { viewModel.updateEvidenceNotes(item.id, it) }
              )
            }

            // Story Editor Modal Dialog
            uiState.storyToEdit?.let { story ->
              StoryEditorDialog(
                story = story,
                onDismiss = { viewModel.closeStoryEditor() },
                onSaveDecision = { stance, slot ->
                  viewModel.updateStoryDecision(story.id, stance, slot)
                }
              )
            }

            // Chapter Resolution Modal Dialog
            uiState.chapterResolution?.let { resolution ->
              ResolutionDialog(
                resolution = resolution,
                onAdvanceChapter = { nextId -> viewModel.advanceToNextChapter(nextId) },
                onDismiss = { viewModel.dismissResolution() }
              )
            }
          }
        }
      }
    }
  }
}
