package com.example.model

enum class EvidenceCategory(val displayName: String) {
  PHYSICAL("Physical Evidence"),
  OFFICIAL_DOCUMENT("Official Document"),
  NEWSPAPER_CLIPPING("Newspaper Clipping"),
  WITNESS_TESTIMONY("Witness Testimony"),
  FINANCIAL_RECORD("Financial Record"),
  CORRESPONDENCE("Correspondence"),
  TIMELINE("Timeline Record"),
  CONTRADICTORY_STATEMENT("Contradiction")
}

enum class EvidenceStatus(val label: String) {
  UNCONFIRMED("Unconfirmed"),
  VERIFIED("Verified Fact"),
  DISPUTED("Disputed")
}

data class EvidenceItem(
  val id: String,
  val chapterId: Int,
  val title: String,
  val category: EvidenceCategory,
  val source: String,
  val dateObtained: String,
  val shortDescription: String,
  val detailedContent: String,
  val peopleInvolved: List<String> = emptyList(),
  val locationsInvolved: List<String> = emptyList(),
  val connections: List<String> = emptyList(),
  val status: EvidenceStatus = EvidenceStatus.UNCONFIRMED,
  val isKeyClue: Boolean = false,
  val userNotes: String = ""
)

data class EvidenceDeduction(
  val id: String,
  val evidenceAId: String,
  val evidenceBId: String,
  val deductionTitle: String,
  val deductionText: String,
  val unlocksLeadId: String? = null,
  val unlocksQuestionForSourceId: String? = null,
  val unlocksStoryId: String? = null,
  val credibilityBonus: Int = 10
)
