package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val NewspaperLightColorScheme = lightColorScheme(
  primary = InkBlack,
  onPrimary = PaperIvory,
  primaryContainer = PaperAged,
  onPrimaryContainer = InkBlack,
  secondary = SepiaBrown,
  onSecondary = PaperIvory,
  secondaryContainer = SepiaFaint,
  onSecondaryContainer = InkBlack,
  tertiary = StampRed,
  onTertiary = PaperIvory,
  background = PaperIvory,
  onBackground = InkBlack,
  surface = PaperSurface,
  onSurface = InkBlack,
  surfaceVariant = PaperAged,
  onSurfaceVariant = InkMuted,
  outline = RuleDivider,
  outlineVariant = RuleLight
)

private val NewspaperDarkColorScheme = darkColorScheme(
  primary = DarkroomText,
  onPrimary = DarkroomBase,
  primaryContainer = DarkroomSurface,
  onPrimaryContainer = DarkroomText,
  secondary = DarkroomSepia,
  onSecondary = DarkroomBase,
  secondaryContainer = DarkroomElevated,
  onSecondaryContainer = DarkroomText,
  tertiary = StampRed,
  onTertiary = DarkroomText,
  background = DarkroomBase,
  onBackground = DarkroomText,
  surface = DarkroomSurface,
  onSurface = DarkroomText,
  surfaceVariant = DarkroomElevated,
  onSurfaceVariant = DarkroomTextMuted,
  outline = DarkroomRule,
  outlineVariant = DarkroomRule
)

@Composable
fun TheLastEditionTheme(
  isDarkTheme: Boolean = false,
  content: @Composable () -> Unit
) {
  val colorScheme = if (isDarkTheme) NewspaperDarkColorScheme else NewspaperLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = NewspaperTypography,
    content = content
  )
}
