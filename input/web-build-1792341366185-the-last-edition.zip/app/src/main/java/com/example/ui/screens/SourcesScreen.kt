package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.GameUiState

@Composable
fun SourcesScreen(
  uiState: GameUiState,
  onStartInterview: (SourceCharacter) -> Unit,
  onSelectDialogueOption: (DialogueOption) -> Unit,
  onEndInterview: () -> Unit,
  modifier: Modifier = Modifier
) {
  val activeSource = uiState.activeInterviewSource

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 12.dp)
  ) {
    // Header
    item {
      NewspaperMasthead(
        editionDate = uiState.currentChapter.historicalDate,
        editionType = "SOURCE MANAGEMENT & INTERVIEW DESK",
        clockTimeFormatted = uiState.clockFormatted,
        minutesRemaining = uiState.minutesRemaining
      )
    }

    if (activeSource != null) {
      // ACTIVE INTERVIEW VIEW
      item {
        InkCard(
          borderColor = MaterialTheme.colorScheme.primary,
          modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "INTERROGATION & INTERVIEW",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = CourierFontFamily,
                color = MaterialTheme.colorScheme.secondary
              )
              Text(
                text = activeSource.name,
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = PlayfairFontFamily,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${activeSource.role} • ${activeSource.affiliation}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            StampBadge(
              text = when {
                activeSource.trustScore >= 40 -> "COOPERATIVE"
                activeSource.trustScore >= 10 -> "CAUTIOUS"
                activeSource.trustScore >= -10 -> "GUARDED"
                else -> "HOSTILE"
              },
              color = when {
                activeSource.trustScore >= 40 -> StampGreen
                activeSource.trustScore >= 10 -> MaterialTheme.colorScheme.secondary
                else -> StampRed
              }
            )
          }

          Spacer(modifier = Modifier.height(4.dp))
          NewspaperSingleRule()
          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "Location: ${activeSource.location}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.secondary
          )
          Text(
            text = "Conflict of Interest: ${activeSource.conflictOfInterest}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Spacer(modifier = Modifier.height(8.dp))
        VintageSectionTitle(title = "Interview Transcript")
        Spacer(modifier = Modifier.height(4.dp))
      }

      // Dialogue History
      items(uiState.interviewHistory) { (speaker, text) ->
        val isPlayer = speaker == "You"
        val isNarrative = speaker == "Narrative"

        InkCard(
          backgroundColor = if (isPlayer) MaterialTheme.colorScheme.surfaceVariant else if (isNarrative) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface,
          borderColor = if (isPlayer) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outlineVariant,
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
        ) {
          Text(
            text = speaker.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (isPlayer) MaterialTheme.colorScheme.primary else if (isNarrative) MaterialTheme.colorScheme.secondary else StampRed
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = text,
            style = if (isNarrative) MaterialTheme.typography.bodySmall else MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }

      // Dialogue Options
      item {
        Spacer(modifier = Modifier.height(10.dp))
        VintageSectionTitle(
          title = "Select Journalistic Stance",
          subtitle = "Choose your question and questioning approach"
        )
        Spacer(modifier = Modifier.height(6.dp))

        val currentNode = activeSource.dialogueTree[uiState.activeDialogueNodeKey]
        val options = currentNode?.options ?: emptyList()

        if (options.isEmpty()) {
          VintageButton(
            text = "End Interview & Return to Desk",
            onClick = onEndInterview,
            modifier = Modifier.fillMaxWidth()
          )
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            options.forEach { option ->
              val hasRequiredEvidence = option.requiredEvidenceId == null ||
                uiState.availableEvidence.any { it.id == option.requiredEvidenceId }

              val isTrustSufficient = activeSource.trustScore >= option.requiredTrustMin

              val isAvailable = hasRequiredEvidence && isTrustSufficient

              InkCard(
                borderColor = if (isAvailable) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                backgroundColor = if (isAvailable) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                onClick = if (isAvailable) { { onSelectDialogueOption(option) } } else null,
                modifier = Modifier.fillMaxWidth().testTag("dialogue_option_${option.id}")
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  StampBadge(
                    text = option.stance.label,
                    color = when (option.stance) {
                      DialogueStance.CHALLENGE_CONTRADICTION -> StampRed
                      DialogueStance.PROTECT_IDENTITY -> StampGreen
                      DialogueStance.PRESENT_EVIDENCE -> MaterialTheme.colorScheme.primary
                      DialogueStance.BARGAIN_INFO -> MaterialTheme.colorScheme.secondary
                      DialogueStance.END_INTERVIEW -> InkMuted
                      else -> MaterialTheme.colorScheme.secondary
                    }
                  )
                  Text(
                    text = "Time: ${option.timeCostMinutes}m",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                  text = option.text,
                  style = MaterialTheme.typography.bodyMedium,
                  fontWeight = FontWeight.SemiBold,
                  color = if (isAvailable) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (!hasRequiredEvidence) {
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = "[LOCKED: Requires verified evidence clue]",
                    style = MaterialTheme.typography.labelSmall,
                    color = StampRed,
                    fontSize = 9.sp
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        VintageButton(
          text = "Conclude Interview",
          onClick = onEndInterview,
          isPrimary = false,
          modifier = Modifier.fillMaxWidth()
        )
      }
    } else {
      // SOURCES DOSSIER DIRECTORY
      item {
        VintageSectionTitle(
          title = "Key Informants & Contacts",
          subtitle = "Tap any person to question them or examine known motives"
        )
        Spacer(modifier = Modifier.height(6.dp))
      }

      items(uiState.activeSources) { source ->
        InkCard(
          onClick = { onStartInterview(source) },
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("source_card_${source.id}")
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = source.name,
                style = MaterialTheme.typography.titleMedium,
                fontFamily = PlayfairFontFamily,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = source.role,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
              )
            }
            StampBadge(
              text = "TRUST: ${source.trustScore}",
              color = if (source.trustScore >= 20) StampGreen else StampRed
            )
          }

          Spacer(modifier = Modifier.height(4.dp))
          NewspaperSingleRule()
          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "Location: ${source.location}",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(2.dp))

          Text(
            text = source.background,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2
          )

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Interviews: ${source.interviewCount}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            VintageButton(
              text = "Question Source",
              onClick = { onStartInterview(source) },
              modifier = Modifier.testTag("interview_btn_${source.id}")
            )
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
