package com.example.model

data class TimelineEvent(
  val id: String,
  val timeLabel: String,
  val location: String,
  val actor: String,
  val eventSummary: String,
  val isVerified: Boolean = false,
  val linkedEvidenceId: String? = null
)

enum class HypothesisStatus(val label: String) {
  UNRESOLVED("Unresolved"),
  CONFIRMED("Confirmed by Evidence"),
  DISPUTED("Disputed by Records")
}

data class HypothesisRecord(
  val id: String,
  val title: String,
  val description: String,
  val supportingEvidenceIds: List<String> = emptyList(),
  val conflictingEvidenceIds: List<String> = emptyList(),
  val status: HypothesisStatus = HypothesisStatus.UNRESOLVED
)
