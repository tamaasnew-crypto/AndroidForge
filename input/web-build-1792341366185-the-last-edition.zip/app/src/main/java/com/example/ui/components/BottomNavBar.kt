package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CourierFontFamily
import com.example.ui.theme.StampRed

enum class NavDestination(
  val label: String,
  val indexCode: String,
  val iconFilled: ImageVector,
  val iconOutlined: ImageVector,
  val testTag: String
) {
  FRONT_PAGE("Front Page", "SEC. A", Icons.Filled.Feed, Icons.Outlined.Feed, "nav_front_page"),
  CITY_DESK("City Desk", "DESK", Icons.Filled.Place, Icons.Outlined.Place, "nav_city_desk"),
  CASE_FILES("Case Files", "DOCS", Icons.Filled.Folder, Icons.Outlined.Folder, "nav_case_files"),
  SOURCES("Sources", "VOX", Icons.Filled.RecordVoiceOver, Icons.Outlined.RecordVoiceOver, "nav_sources"),
  ARCHIVE("Archive", "INDEX", Icons.Filled.HistoryEdu, Icons.Outlined.HistoryEdu, "nav_archive")
}

@Composable
fun NewspaperBottomIndexBar(
  currentDestination: NavDestination,
  onNavigate: (NavDestination) -> Unit,
  unreadEvidenceCount: Int = 0,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(MaterialTheme.colorScheme.surface)
      .navigationBarsPadding()
  ) {
    NewspaperDoubleRule(modifier = Modifier.fillMaxWidth())

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .height(58.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      NavDestination.values().forEach { destination ->
        val isSelected = destination == currentDestination
        val contentColor = if (isSelected) {
          MaterialTheme.colorScheme.onBackground
        } else {
          MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        }

        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .testTag(destination.testTag)
            .clickable { onNavigate(destination) }
            .padding(vertical = 4.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
          ) {
            Box {
              Icon(
                imageVector = if (isSelected) destination.iconFilled else destination.iconOutlined,
                contentDescription = destination.label,
                tint = contentColor,
                modifier = Modifier.size(22.dp)
              )
              if (destination == NavDestination.CASE_FILES && unreadEvidenceCount > 0) {
                Box(
                  modifier = Modifier
                    .size(8.dp)
                    .align(Alignment.TopEnd)
                    .background(StampRed, androidx.compose.foundation.shape.CircleShape)
                )
              }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
              text = destination.label.uppercase(),
              style = MaterialTheme.typography.labelSmall,
              fontFamily = CourierFontFamily,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
              fontSize = 9.5.sp,
              color = contentColor
            )

            Text(
              text = destination.indexCode,
              style = MaterialTheme.typography.labelSmall,
              fontSize = 7.5.sp,
              color = if (isSelected) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outlineVariant
            )
          }
        }
      }
    }
  }
}
