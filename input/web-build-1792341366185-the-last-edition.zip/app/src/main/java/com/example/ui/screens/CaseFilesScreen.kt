package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameContentRepository
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.GameUiState

enum class CaseFilesTab(val label: String) {
  EVIDENCE("Evidence Drawer"),
  COMPARE("Compare & Deduce"),
  TIMELINE("Crime Timeline")
}

@Composable
fun CaseFilesScreen(
  uiState: GameUiState,
  onOpenEvidenceDetail: (EvidenceItem) -> Unit,
  onSetCompareA: (EvidenceItem?) -> Unit,
  onSetCompareB: (EvidenceItem?) -> Unit,
  onExecuteDeduction: () -> Unit,
  onDismissDeductionResult: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableStateOf(CaseFilesTab.EVIDENCE) }
  var selectedCategory by remember { mutableStateOf<EvidenceCategory?>(null) }
  var searchQuery by remember { mutableStateOf("") }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .padding(horizontal = 12.dp)
  ) {
    // Header
    item {
      NewspaperMasthead(
        editionDate = uiState.currentChapter.historicalDate,
        editionType = "CASE FILES & EVIDENCE REPOSITORY",
        clockTimeFormatted = uiState.clockFormatted,
        minutesRemaining = uiState.minutesRemaining
      )
    }

    // Tab Selector
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        CaseFilesTab.values().forEach { tab ->
          val isSelected = tab == selectedTab
          Button(
            onClick = { selectedTab = tab },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
              contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
            ),
            shape = MaterialTheme.shapes.extraSmall,
            modifier = Modifier
              .weight(1f)
              .defaultMinSize(minHeight = 44.dp)
              .border(1.dp, MaterialTheme.colorScheme.outline)
              .testTag("tab_${tab.name.lowercase()}")
          ) {
            Text(
              text = tab.label.uppercase(),
              style = MaterialTheme.typography.labelSmall,
              fontFamily = CourierFontFamily,
              fontWeight = FontWeight.Bold,
              fontSize = 9.5.sp,
              textAlign = TextAlign.Center
            )
          }
        }
      }
      NewspaperSingleRule()
      Spacer(modifier = Modifier.height(8.dp))
    }

    when (selectedTab) {
      CaseFilesTab.EVIDENCE -> {
        // Search & Category Filters
        item {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search evidence, people, or locations...", style = MaterialTheme.typography.bodySmall) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.secondary) },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { searchQuery = "" }) {
                  Icon(Icons.Filled.Close, contentDescription = "Clear")
                }
              }
            },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("search_evidence_input")
          )
          Spacer(modifier = Modifier.height(6.dp))

          // Filter pills
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
          ) {
            item {
              FilterChip(
                selected = selectedCategory == null,
                onClick = { selectedCategory = null },
                label = { Text("ALL (${uiState.availableEvidence.size})", style = MaterialTheme.typography.labelSmall) }
              )
            }
            items(EvidenceCategory.values()) { cat ->
              val count = uiState.availableEvidence.count { it.category == cat }
              if (count > 0) {
                FilterChip(
                  selected = selectedCategory == cat,
                  onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                  label = { Text("${cat.displayName.uppercase()} ($count)", style = MaterialTheme.typography.labelSmall) }
                )
              }
            }
          }
        }

        // Filtered Evidence list
        val filteredEvidence = uiState.availableEvidence.filter { item ->
          val matchesCat = selectedCategory == null || item.category == selectedCategory
          val matchesSearch = searchQuery.isBlank() ||
            item.title.contains(searchQuery, ignoreCase = true) ||
            item.detailedContent.contains(searchQuery, ignoreCase = true) ||
            item.peopleInvolved.any { it.contains(searchQuery, ignoreCase = true) } ||
            item.locationsInvolved.any { it.contains(searchQuery, ignoreCase = true) }
          matchesCat && matchesSearch
        }

        if (filteredEvidence.isEmpty()) {
          item {
            InkCard(modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
              Text(
                text = "No evidence matching search criteria.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
              )
            }
          }
        } else {
          items(filteredEvidence) { item ->
            InkCard(
              borderColor = if (item.isKeyClue) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
              backgroundColor = MaterialTheme.colorScheme.surface,
              onClick = { onOpenEvidenceDetail(item) },
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .testTag("evidence_item_${item.id}")
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = item.category.displayName.uppercase(),
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.secondary
                )
                StampBadge(
                  text = item.status.label,
                  color = when (item.status) {
                    EvidenceStatus.VERIFIED -> StampGreen
                    EvidenceStatus.DISPUTED -> StampRed
                    EvidenceStatus.UNCONFIRMED -> InkMuted
                  }
                )
              }

              Spacer(modifier = Modifier.height(4.dp))

              Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium,
                fontFamily = PlayfairFontFamily,
                fontWeight = FontWeight.Bold
              )

              Spacer(modifier = Modifier.height(2.dp))

              Text(
                text = item.shortDescription,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2
              )

              Spacer(modifier = Modifier.height(6.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "Source: ${item.source}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  fontSize = 9.sp
                )
                Text(
                  text = "TAP TO INSPECT",
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
          }
        }
      }

      CaseFilesTab.COMPARE -> {
        // COMPARE & DEDUCE BOARD
        item {
          VintageSectionTitle(
            title = "Evidence Contradiction Board",
            subtitle = "Place two records side-by-side to cross-reference claims and uncover leads"
          )
          Spacer(modifier = Modifier.height(8.dp))

          // Two Comparison Slots
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            // Slot A
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "SLOT A: PRIMARY RECORD",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Spacer(modifier = Modifier.height(4.dp))
              if (uiState.compareEvidenceA != null) {
                InkCard(
                  borderColor = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text(
                    text = uiState.compareEvidenceA.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontFamily = PlayfairFontFamily,
                    fontWeight = FontWeight.Bold
                  )
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = uiState.compareEvidenceA.category.displayName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  TextButton(
                    onClick = { onSetCompareA(null) },
                    contentPadding = PaddingValues(0.dp)
                  ) {
                    Text("CLEAR", style = MaterialTheme.typography.labelSmall, color = StampRed)
                  }
                }
              } else {
                InkCard(
                  modifier = Modifier.fillMaxWidth().height(100.dp)
                ) {
                  Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                      text = "Tap an evidence item below to place in Slot A",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      textAlign = TextAlign.Center
                    )
                  }
                }
              }
            }

            // Slot B
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "SLOT B: CORROBORATING RECORD",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Spacer(modifier = Modifier.height(4.dp))
              if (uiState.compareEvidenceB != null) {
                InkCard(
                  borderColor = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text(
                    text = uiState.compareEvidenceB.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontFamily = PlayfairFontFamily,
                    fontWeight = FontWeight.Bold
                  )
                  Spacer(modifier = Modifier.height(2.dp))
                  Text(
                    text = uiState.compareEvidenceB.category.displayName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  TextButton(
                    onClick = { onSetCompareB(null) },
                    contentPadding = PaddingValues(0.dp)
                  ) {
                    Text("CLEAR", style = MaterialTheme.typography.labelSmall, color = StampRed)
                  }
                }
              } else {
                InkCard(
                  modifier = Modifier.fillMaxWidth().height(100.dp)
                ) {
                  Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                      text = "Tap an evidence item below to place in Slot B",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      textAlign = TextAlign.Center
                    )
                  }
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Deduction Action Button
          VintageButton(
            text = "Cross-Reference & Form Deduction (15m)",
            onClick = onExecuteDeduction,
            enabled = uiState.compareEvidenceA != null && uiState.compareEvidenceB != null,
            modifier = Modifier.fillMaxWidth().testTag("execute_deduction_btn")
          )

          // Deduction mismatch feedback
          if (uiState.deductionMismatchMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            InkCard(
              borderColor = StampRed,
              backgroundColor = StampRed.copy(alpha = 0.05f),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = "NO CONTRADICTION FOUND",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = StampRed
              )
              Text(
                text = uiState.deductionMismatchMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))
          NewspaperSingleRule()
          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = "TAP ANY CLUE TO LOAD INTO OPEN SLOT:",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.secondary
          )
          Spacer(modifier = Modifier.height(4.dp))
        }

        items(uiState.availableEvidence) { item ->
          InkCard(
            onClick = {
              if (uiState.compareEvidenceA == null) {
                onSetCompareA(item)
              } else if (uiState.compareEvidenceB == null && item.id != uiState.compareEvidenceA.id) {
                onSetCompareB(item)
              } else {
                onSetCompareA(item)
              }
            },
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall,
                fontFamily = PlayfairFontFamily,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
              )
              Text(
                text = item.category.displayName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
              )
            }
          }
        }
      }

      CaseFilesTab.TIMELINE -> {
        // TIMELINE VIEW
        item {
          VintageSectionTitle(
            title = "Reconstructed Night Timeline",
            subtitle = "Chronological chain of events on the night of October 18-19, 1947"
          )
          Spacer(modifier = Modifier.height(8.dp))
        }

        items(GameContentRepository.timelineEvents) { event ->
          InkCard(
            borderColor = if (event.isVerified) StampGreen else MaterialTheme.colorScheme.outlineVariant,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              StampBadge(text = event.timeLabel, color = MaterialTheme.colorScheme.primary)
              Text(
                text = event.location.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
              )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = "Actor: ${event.actor}",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
              text = event.eventSummary,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = if (event.isVerified) "VERIFIED BY OFFICIAL RECORD" else "UNVERIFIED ALLEGATION",
                style = MaterialTheme.typography.labelSmall,
                color = if (event.isVerified) StampGreen else StampRed,
                fontSize = 9.sp
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
    }
  }

  // Breakthrough Deduction Modal Dialog
  if (uiState.lastDeductionResult != null) {
    val deduction = uiState.lastDeductionResult
    AlertDialog(
      onDismissRequest = onDismissDeductionResult,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = StampRed)
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "EDITORIAL DEDUCTION",
            fontFamily = PlayfairFontFamily,
            fontWeight = FontWeight.Bold
          )
        }
      },
      text = {
        Column {
          StampBadge(text = "VERIFIED INCONSISTENCY", color = StampGreen)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = deduction.deductionTitle,
            style = MaterialTheme.typography.titleMedium,
            fontFamily = PlayfairFontFamily,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = deduction.deductionText,
            style = MaterialTheme.typography.bodyMedium
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "+${deduction.credibilityBonus}% Reader Credibility Earned",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = StampGreen
          )
        }
      },
      confirmButton = {
        TextButton(
          onClick = onDismissDeductionResult,
          modifier = Modifier.testTag("dismiss_deduction_btn")
        ) {
          Text("PROCEED WITH INVESTIGATION", fontWeight = FontWeight.Bold)
        }
      }
    )
  }
}
