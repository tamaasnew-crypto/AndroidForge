package com.example.model

enum class EditorialStance(val label: String, val description: String) {
  PUBLISH_FULL("Publish Full Exposé", "Run the hard-hitting story naming names and citing verified documents."),
  PUBLISH_CAUTIOUS("Cautious Report", "Carefully distinguish established facts from unverified allegations."),
  DELAY_VERIFICATION("Hold for Further Proof", "Keep story in reserve until secondary confirmation is secured."),
  KILL_STORY("Spike / Suppress", "Kill the article completely to protect sources or avoid legal exposure.")
}

enum class StorySlot(val label: String) {
  LEAD_BANNER("Lead Banner Headline"),
  SECONDARY_COLUMN("Front Page Column 2"),
  WIRE_SIDEBAR("City Wire Brief")
}

data class NewspaperStory(
  val id: String,
  val chapterId: Int,
  val headline: String,
  val subHeadline: String,
  val authorByline: String,
  val fullArticleText: String,
  val cautiousArticleText: String,
  val requiredEvidenceIds: List<String> = emptyList(),
  val verificationLevel: String, // "Fully Verified", "Single Source", "Circumstantial"
  val legalRisk: String, // "High", "Moderate", "Negligible"
  val politicalImpact: String,
  val selectedStance: EditorialStance = EditorialStance.DELAY_VERIFICATION,
  val assignedSlot: StorySlot? = null
)

data class PrintedEdition(
  val editionNumber: Int,
  val dateString: String,
  val editionTitle: String,
  val leadHeadline: String,
  val leadBody: String,
  val columnHeadline: String,
  val columnBody: String,
  val sidebarHeadline: String,
  val sidebarBody: String,
  val publicTrustScore: Int,
  val policePressureScore: Int,
  val legalExposureScore: Int,
  val editorialSummary: String
)
