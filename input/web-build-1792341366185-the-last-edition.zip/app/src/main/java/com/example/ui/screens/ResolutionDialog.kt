package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ChapterResolution
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun ResolutionDialog(
  resolution: ChapterResolution,
  onAdvanceChapter: (Int) -> Unit,
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = MaterialTheme.shapes.extraSmall,
      color = MaterialTheme.colorScheme.surface,
      border = androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary),
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 12.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(16.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        StampBadge(text = "EXTRA! MORNING FINAL RUN", color = StampRed)

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "The Greybridge Gazette",
          style = MaterialTheme.typography.displaySmall,
          fontFamily = PlayfairFontFamily,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(2.dp))
        NewspaperDoubleRule()
        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = resolution.headlineChosen,
          style = MaterialTheme.typography.headlineMedium,
          fontFamily = PlayfairFontFamily,
          fontWeight = FontWeight.Bold,
          textAlign = TextAlign.Center,
          color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(6.dp))
        NewspaperSingleRule()
        Spacer(modifier = Modifier.height(8.dp))

        // Outcome Metrics
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(8.dp),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("READER TRUST", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
            Text(
              text = "+${resolution.publicTrustDelta}%",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = StampGreen
            )
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("POLICE HEAT", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
            Text(
              text = "+${resolution.policeHeatDelta}%",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = StampRed
            )
          }
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("DEADLINE MET", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
            Text(
              text = if (resolution.wasDeadlineMet) "SUCCESS" else "DELAYED",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = if (resolution.wasDeadlineMet) StampGreen else StampRed
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = resolution.narrativeEpilogue,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurface,
          lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        if (resolution.unlockedNextChapterId != null) {
          VintageButton(
            text = "Proceed to Chapter ${resolution.unlockedNextChapterId}",
            onClick = { onAdvanceChapter(resolution.unlockedNextChapterId) },
            modifier = Modifier.fillMaxWidth().testTag("advance_chapter_btn")
          )
          Spacer(modifier = Modifier.height(6.dp))
        }

        VintageButton(
          text = "Inspect Historical Morgue",
          onClick = onDismiss,
          isPrimary = false,
          modifier = Modifier.fillMaxWidth().testTag("dismiss_resolution_btn")
        )
      }
    }
  }
}
