package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PlayfairFontFamily
import com.example.ui.theme.CourierFontFamily
import com.example.ui.theme.StampRed

@Composable
fun NewspaperMasthead(
  editionDate: String,
  editionType: String = "NIGHT FINAL EDITION",
  clockTimeFormatted: String = "11:00 PM",
  minutesRemaining: Int = 240,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 12.dp, vertical = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Top fine rule
    NewspaperDoubleRule(modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp))

    // Top Latin Motto and Issue info
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "EST. 1888 • GREYBRIDGE, ORE.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Text(
        text = "VERITAS IN OBSCURIS",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.secondary
      )
      Text(
        text = "TWO CENTS",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }

    Spacer(modifier = Modifier.height(2.dp))

    // Huge authentic Masthead title
    Text(
      text = "The Greybridge Gazette",
      style = MaterialTheme.typography.displayMedium,
      fontFamily = PlayfairFontFamily,
      fontWeight = FontWeight.Bold,
      textAlign = TextAlign.Center,
      letterSpacing = (-0.5).sp,
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(2.dp))

    // Bottom Dateline & Deadline ticker
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .padding(horizontal = 8.dp, vertical = 3.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "$editionDate • $editionType",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurface
      )
      // Clock and time until 03:00 AM print run
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "TIME: $clockTimeFormatted",
          style = MaterialTheme.typography.labelMedium,
          fontWeight = FontWeight.Bold,
          color = if (minutesRemaining <= 45) StampRed else MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "(${minutesRemaining}m to press)",
          style = MaterialTheme.typography.labelSmall,
          color = if (minutesRemaining <= 45) StampRed else MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    NewspaperDoubleRule(modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
  }
}

@Composable
fun NewspaperDoubleRule(
  modifier: Modifier = Modifier,
  color: Color = MaterialTheme.colorScheme.outline
) {
  Column(modifier = modifier) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(1.5.dp)
        .background(color)
    )
    Spacer(modifier = Modifier.height(2.dp))
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(0.75.dp)
        .background(color.copy(alpha = 0.7f))
    )
  }
}

@Composable
fun NewspaperSingleRule(
  modifier: Modifier = Modifier,
  color: Color = MaterialTheme.colorScheme.outlineVariant
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(1.dp)
      .background(color)
  )
}
