package com.example.model

data class JournalEntry(
  val id: String,
  val timestampLabel: String,
  val text: String,
  val chapterId: Int,
  val isImportant: Boolean = false
)

data class GameSettings(
  val fontScaleFactor: Float = 1.0f,
  val isReducedTexture: Boolean = false,
  val isDarkroomMode: Boolean = false,
  val hapticsEnabled: Boolean = true
)

data class GameSaveData(
  val saveVersion: Int = 1,
  val currentChapterId: Int = 1,
  val elapsedNightMinutes: Int = 0, // 0 to 240 mins (11:00 PM to 03:00 AM)
  val publicTrustScore: Int = 65, // 0 to 100
  val policeHeatScore: Int = 20, // 0 to 100
  val legalRiskScore: Int = 15, // 0 to 100
  val unlockedEvidenceIds: List<String> = emptyList(),
  val evidenceStatuses: Map<String, String> = emptyMap(), // evidenceId -> EvidenceStatus
  val evidenceNotes: Map<String, String> = emptyMap(),
  val unlockedLeadIds: List<String> = emptyList(),
  val completedLeadIds: List<String> = emptyList(),
  val sourceTrustScores: Map<String, Int> = emptyMap(),
  val sourceDialoguePositions: Map<String, String> = emptyMap(),
  val sourceInterviewCounts: Map<String, Int> = emptyMap(),
  val storyDecisions: Map<String, String> = emptyMap(), // storyId -> EditorialStance
  val storySlotAssignments: Map<String, String> = emptyMap(), // storyId -> StorySlot
  val completedDeductionIds: List<String> = emptyList(),
  val unlockedHypothesisIds: List<String> = emptyList(),
  val hypothesisStatuses: Map<String, String> = emptyMap(),
  val printedEditions: List<PrintedEdition> = emptyList(),
  val journalEntries: List<JournalEntry> = emptyList(),
  val completedChapterIds: List<Int> = emptyList(),
  val isTutorialActive: Boolean = true,
  val tutorialStep: Int = 1,
  val tutorialCompleted: Boolean = false,
  val lastSavedTimestamp: Long = System.currentTimeMillis()
)

data class SaveSlotSummary(
  val slotIndex: Int,
  val isEmpty: Boolean,
  val chapterTitle: String = "",
  val chapterNumber: Int = 1,
  val dateFormatted: String = "",
  val gameTimeFormatted: String = ""
)
