package com.example.model

enum class DialogueStance(val label: String, val description: String) {
  NEUTRAL_QUESTION("Inquire Evenly", "Careful, professional journalistic inquiry without revealing cards."),
  PRESENT_EVIDENCE("Present Evidence", "Confront the source with documented facts to test their account."),
  CHALLENGE_CONTRADICTION("Challenge Inconsistency", "Press them sharply on conflicting times, dates, or statements."),
  PROTECT_IDENTITY("Pledge Confidentiality", "Offer off-the-record protection to establish trust and openness."),
  BARGAIN_INFO("Trade Information", "Exchange a verified tip to coax out crucial details."),
  END_INTERVIEW("Conclude Professionally", "Politely wrap up the interview preserving mutual standing.")
}

data class DialogueOption(
  val id: String,
  val text: String,
  val stance: DialogueStance,
  val requiredEvidenceId: String? = null,
  val requiredTrustMin: Int = -100,
  val responseText: String,
  val trustDelta: Int = 0,
  val revealsEvidenceId: String? = null,
  val revealsLeadId: String? = null,
  val timeCostMinutes: Int = 30,
  val nextDialogueKey: String? = null
)

data class SourceDialogueNode(
  val nodeKey: String,
  val prompt: String,
  val options: List<DialogueOption>
)

data class SourceCharacter(
  val id: String,
  val name: String,
  val role: String,
  val affiliation: String,
  val location: String,
  val background: String,
  val knownInformation: String,
  val conflictOfInterest: String,
  val trustScore: Int = 10, // -100 to 100
  val interviewCount: Int = 0,
  val isConfidentialSource: Boolean = false,
  val isHostile: Boolean = false,
  val dialogueTree: Map<String, SourceDialogueNode> = emptyMap(),
  val defaultDialogueKey: String = "root"
)
