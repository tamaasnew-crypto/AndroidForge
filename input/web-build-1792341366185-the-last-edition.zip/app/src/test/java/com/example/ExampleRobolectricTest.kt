package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GameContentRepository
import com.example.data.SaveManager
import com.example.model.GameSaveData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context matches The Last Edition`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("The Last Edition", appName)
  }

  @Test
  fun `all eight chapters are defined with valid objectives`() {
    val chapters = GameContentRepository.chapters
    assertEquals(8, chapters.size)
    chapters.forEach { chapter ->
      assertTrue(chapter.title.isNotBlank())
      assertTrue(chapter.narrativeIntro.isNotBlank())
      assertTrue(chapter.initialEvidenceIds.isNotEmpty())
    }
  }

  @Test
  fun `chapter 1 key deduction exists between future paper and police memo`() {
    val deduction = GameContentRepository.allDeductions.find { it.id == "ded_c1_prewritten_leak" }
    assertNotNull(deduction)
    assertEquals("ev_c1_future_paper", deduction?.evidenceAId)
    assertEquals("ev_c1_police_memo", deduction?.evidenceBId)
  }

  @Test
  fun `save manager saves and loads campaign state cleanly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val saveManager = SaveManager(context)
    val testData = GameSaveData(
      currentChapterId = 1,
      elapsedNightMinutes = 45,
      publicTrustScore = 80,
      unlockedEvidenceIds = listOf("ev_c1_future_paper", "ev_c1_police_memo")
    )
    val saved = saveManager.saveGame(1, testData)
    assertTrue(saved)

    val loaded = saveManager.loadGame(1)
    assertNotNull(loaded)
    assertEquals(1, loaded?.currentChapterId)
    assertEquals(45, loaded?.elapsedNightMinutes)
    assertEquals(80, loaded?.publicTrustScore)
    assertEquals(2, loaded?.unlockedEvidenceIds?.size)
  }
}
